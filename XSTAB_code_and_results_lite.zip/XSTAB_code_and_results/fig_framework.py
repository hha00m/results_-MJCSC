"""Fig. 1: measurement framework and STAX pipeline (matplotlib patches)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 7.0, "mathtext.fontset": "dejavuserif"})
INK, MUTED, EDGE = "#0b0b0b", "#52514e", "#52514e"
FILL_A, FILL_B, FILL_C = "#eaf2fc", "#fdeee7", "#e7f6f0"

fig, ax = plt.subplots(figsize=(7.2, 3.9))
ax.set_xlim(0, 100); ax.set_ylim(0, 56); ax.axis("off")


def box(x, y, w, h, title, body, fill):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2",
                                fc=fill, ec=EDGE, lw=0.8))
    ax.text(x + w / 2, y + h - 2.2, title, ha="center", va="top", fontweight="bold", color=INK, fontsize=7.0)
    ax.text(x + w / 2, y + h - 6.0, body, ha="center", va="top", color=MUTED, fontsize=6.0,
            linespacing=1.35)


def arrow(x0, y0, x1, y1, txt=None, dy=1.3):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=9,
                                 lw=0.9, color=INK))
    if txt:
        ax.text((x0 + x1) / 2, (y0 + y1) / 2 + dy, txt, ha="center", fontsize=6.8, color=MUTED)

# Row 1: measurement
ax.text(1, 54.5, "(a) Measuring attribution drift", fontweight="bold", color=INK)
box(1, 32, 17, 19, "Training data $D$", "NSL-KDD or\nUNSW-NB15\n40,000-flow samples\nnormal vs attack", FILL_A)
box(23, 32, 20, 19, "Drift source $\\mathcal{S}$", "seed $\\xi$ ($D$ fixed)\nretrain: $D$ resampled\nmix shift: $\\pi_\\lambda$, Eq. (2)\nfamily change\n(Rashomon)", FILL_A)
box(48, 32, 17, 19, "Model pool $\\{f_m\\}$", "LR · RF · HGB · MLP\n10 seed + 32 retrain\n+ 20 shifted members", FILL_A)
box(70, 32, 13.5, 19, "Explainer $\\phi$", "linear SHAP\nTreeSHAP\nIntegrated Grad.\ngrouped, Eq. (1)", FILL_A)
box(87.5, 32, 12, 19, "Stability", "$J_k$, $A_1$: Eq. (3)\n$S_k$: Eq. (4)\n$\\tau$, $J_k^{glob}$: Eq. (5)\n$\\bar{J}_k$: Eq. (6)", FILL_A)
arrow(18.9, 41.5, 22.2, 41.5); arrow(43.9, 41.5, 47.2, 41.5); arrow(65.9, 41.5, 69.2, 41.5); arrow(84.4, 41.5, 86.7, 41.5)

# Row 2: STAX
ax.text(1, 27.5, "(b) STAX: stability-aware aggregation and certification", fontweight="bold", color=INK)
box(1, 4, 19, 19, "$K$ members", "independent seeds\nand data resamples\n$f_1,\\ldots,f_K$", FILL_B)
box(25, 4, 21, 19, "Deployed ensemble", "$F_K$ = mean of $f_m$\n$\\Phi_K$ = mean of $\\phi(f_m)$\n$=\\phi(F_K)$, Eq. (7)", FILL_B)
box(51, 4, 21, 19, "Member bootstrap", "$B$ resamples of members\n$p_g(\\mathbf{x})$: top-$k$ frequency\nEq. (10)", FILL_B)
box(77, 4, 22.5, 19, "Analyst view", "certified top-$k$: $\\mathcal{C}_\\delta(\\mathbf{x})$\n($p_g\\geq 1-\\delta$)\nother top-$k$ features\nflagged unstable", FILL_C)
arrow(20.9, 13.5, 24.2, 13.5); arrow(46.9, 13.5, 50.2, 13.5); arrow(72.9, 13.5, 76.2, 13.5)
ax.text(35.5, 1.0, "Proposition 1: same-distribution variance shrinks as $1/K$; drift from a changed attack mix (bias) does not, Eq. (8)", ha="center", fontsize=6.8,
        color=MUTED, style="italic")
fig.savefig("/home/claude/xstab/figures/fig1_framework.png", dpi=300, bbox_inches="tight")
print("ok")
