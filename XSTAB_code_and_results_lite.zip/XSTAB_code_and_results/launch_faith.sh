#!/bin/bash
cd /home/claude/xstab
for ds in nslkdd unsw; do
  if [ -f results/faith_${ds}_mlp.json ]; then continue; fi
  if ps -eo cmd | grep -q "^python3 faith.py $ds"; then echo "running $ds"; exit; fi
  OMP_NUM_THREADS=1 setsid nohup python3 faith.py $ds > results/faith_$ds.log 2>&1 < /dev/null & sleep 1; echo "started $ds"; exit
done
echo "all done"
