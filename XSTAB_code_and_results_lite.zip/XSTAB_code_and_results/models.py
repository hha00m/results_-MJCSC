"""Model families and deterministic attribution methods.

Every explainer used for the main study is deterministic given a trained
model, so that any attribution drift we measure is caused by the training
process (seed, data resample, data mix), not by explainer sampling noise.

  lr  : logistic regression; exact linear SHAP  phi_j = w_j (x_j - E[x_j])   (log-odds)
  rf  : random forest;      TreeSHAP (path-dependent), class-1 probability
  hgb : hist. gradient boosting; TreeSHAP (path-dependent), log-odds
  mlp : 2-layer ReLU MLP;   Integrated Gradients on the logit, baseline E[x]
"""
import numpy as np
import shap
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.neural_network import MLPClassifier

FAMILIES = ["lr", "rf", "hgb", "mlp"]


def train(family, X, y, seed):
    if family == "lr":
        m = LogisticRegression(C=1.0, max_iter=20000, tol=1e-10)
    elif family == "rf":
        m = RandomForestClassifier(n_estimators=100, max_depth=20, min_samples_leaf=2,
                                   max_features="sqrt", n_jobs=2, random_state=seed)
    elif family == "hgb":
        m = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.1,
                                           early_stopping=True, validation_fraction=0.1,
                                           random_state=seed)
    elif family == "mlp":
        m = MLPClassifier(hidden_layer_sizes=(64, 32), alpha=1e-4, batch_size=256,
                          learning_rate_init=1e-3, max_iter=200, early_stopping=True,
                          n_iter_no_change=8, random_state=seed)
    else:
        raise ValueError(family)
    m.fit(X, y)
    return m


def _mlp_logit_and_grad(m, X):
    """Forward pass and d(logit)/dx for a sklearn MLPClassifier (relu, binary)."""
    acts, pre = [X], []
    h = X
    for i, (W, b) in enumerate(zip(m.coefs_, m.intercepts_)):
        z = h @ W + b
        pre.append(z)
        h = np.maximum(z, 0) if i < len(m.coefs_) - 1 else z
        acts.append(h)
    logit = h[:, 0]
    g = np.ones((X.shape[0], 1))
    for i in range(len(m.coefs_) - 1, -1, -1):
        if i < len(m.coefs_) - 1:
            g = g * (pre[i] > 0)
        g = g @ m.coefs_[i].T
    return logit, g


def integrated_gradients(m, X, base, steps=64):
    alphas = (np.arange(steps) + 0.5) / steps
    tot = np.zeros_like(X, dtype=float)
    for a in alphas:
        _, g = _mlp_logit_and_grad(m, base + a * (X - base))
        tot += g
    return (X - base) * tot / steps


def attribute(family, m, X, xbar):
    """Column-level local attributions (n x d)."""
    X = np.asarray(X, dtype=float)
    if family == "lr":
        return m.coef_[0][None, :] * (X - xbar[None, :])
    if family == "mlp":
        return integrated_gradients(m, X, xbar[None, :])
    e = shap.TreeExplainer(m)
    v = e.shap_values(X, check_additivity=False)
    v = np.asarray(v)
    if v.ndim == 3:            # (n, d, classes) for RF
        v = v[:, :, 1]
    return v


def logit_of(family, m, X):
    """Model output in the space its attributions explain (for completeness checks)."""
    if family == "mlp":
        return _mlp_logit_and_grad(m, np.asarray(X, float))[0]
    if family == "rf":
        return m.predict_proba(X)[:, 1]
    return m.decision_function(X)
