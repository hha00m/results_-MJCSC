"""Data loading and preprocessing for NSL-KDD and UNSW-NB15.

Both datasets are cast as binary (normal = 0, attack = 1). Categorical
columns are one-hot encoded for the models, and a group map records which
encoded columns belong to which original feature so that attributions can
be summed back to the analyst-facing feature level.
"""
import numpy as np
import pandas as pd

DATA = "/home/claude/xstab/data"

KDD_COLS = [
    "duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes", "land",
    "wrong_fragment", "urgent", "hot", "num_failed_logins", "logged_in", "num_compromised",
    "root_shell", "su_attempted", "num_root", "num_file_creations", "num_shells",
    "num_access_files", "num_outbound_cmds", "is_host_login", "is_guest_login", "count",
    "srv_count", "serror_rate", "srv_serror_rate", "rerror_rate", "srv_rerror_rate",
    "same_srv_rate", "diff_srv_rate", "srv_diff_host_rate", "dst_host_count",
    "dst_host_srv_count", "dst_host_same_srv_rate", "dst_host_diff_srv_rate",
    "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate", "dst_host_serror_rate",
    "dst_host_srv_serror_rate", "dst_host_rerror_rate", "dst_host_srv_rerror_rate",
    "label", "difficulty"]

# NSL-KDD attack-name -> family (Tavallaee et al. grouping)
KDD_FAMILY = {
    "normal": "normal",
    **{a: "dos" for a in ["back", "land", "neptune", "pod", "smurf", "teardrop", "apache2",
                         "mailbomb", "processtable", "udpstorm"]},
    **{a: "probe" for a in ["ipsweep", "nmap", "portsweep", "satan", "mscan", "saint"]},
    **{a: "r2l" for a in ["ftp_write", "guess_passwd", "imap", "multihop", "phf", "spy",
                         "warezclient", "warezmaster", "sendmail", "named", "snmpgetattack",
                         "snmpguess", "xlock", "xsnoop", "worm"]},
    **{a: "u2r" for a in ["buffer_overflow", "loadmodule", "perl", "rootkit", "httptunnel",
                         "ps", "sqlattack", "xterm"]},
}


def _encode(train, test, cat_cols, num_cols):
    """log1p + standardise numerics (fit on train); one-hot categoricals with
    the train vocabulary (unseen test levels -> all zeros)."""
    blocks_tr, blocks_te, names, groups = [], [], [], []
    for c in num_cols:
        a = np.log1p(np.clip(train[c].astype(float).values, 0, None))
        b = np.log1p(np.clip(test[c].astype(float).values, 0, None))
        mu, sd = a.mean(), a.std() + 1e-9
        blocks_tr.append(((a - mu) / sd)[:, None]); blocks_te.append(((b - mu) / sd)[:, None])
        names.append(c); groups.append(c)
    for c in cat_cols:
        levels = sorted(train[c].astype(str).unique())
        idx = {v: i for i, v in enumerate(levels)}
        A = np.zeros((len(train), len(levels)), np.float32)
        B = np.zeros((len(test), len(levels)), np.float32)
        A[np.arange(len(train)), train[c].astype(str).map(idx).values] = 1
        bm = test[c].astype(str).map(idx)
        ok = bm.notna().values
        B[np.where(ok)[0], bm[ok].astype(int).values] = 1
        blocks_tr.append(A); blocks_te.append(B)
        names += [f"{c}={v}" for v in levels]; groups += [c] * len(levels)
    Xtr = np.hstack(blocks_tr).astype(np.float32)
    Xte = np.hstack(blocks_te).astype(np.float32)
    gnames = list(dict.fromkeys(groups))
    gidx = np.array([gnames.index(g) for g in groups])
    return Xtr, Xte, names, gnames, gidx


def load(name):
    """Returns dict with Xtr, ytr, ftr (family), Xte, yte, fte, colnames,
    group names, group index per column."""
    if name == "nslkdd":
        tr = pd.read_csv(f"{DATA}/KDDTrain+.txt", header=None, names=KDD_COLS)
        te = pd.read_csv(f"{DATA}/KDDTest+.txt", header=None, names=KDD_COLS)
        for d in (tr, te):
            d["family"] = d["label"].map(KDD_FAMILY).fillna("other")
            d["y"] = (d["label"] != "normal").astype(int)
        cat = ["protocol_type", "service", "flag"]
        # num_outbound_cmds is constant zero in NSL-KDD -> dropped
        num = [c for c in KDD_COLS[:-2] if c not in cat and c != "num_outbound_cmds"]
    elif name == "unsw":
        tr = pd.read_csv(f"{DATA}/UNSW_NB15_training-set.csv")
        te = pd.read_csv(f"{DATA}/UNSW_NB15_testing-set.csv")
        tr.columns = [c.strip().lstrip("﻿") for c in tr.columns]
        te.columns = [c.strip().lstrip("﻿") for c in te.columns]
        for d in (tr, te):
            d["family"] = d["attack_cat"].astype(str).str.strip().str.lower()
            d["y"] = d["label"].astype(int)
        cat = ["proto", "service", "state"]
        num = [c for c in tr.columns if c not in cat + ["id", "attack_cat", "label", "family", "y"]]
    else:
        raise ValueError(name)
    Xtr, Xte, cols, gnames, gidx = _encode(tr, te, cat, num)
    return dict(Xtr=Xtr, ytr=tr["y"].values, ftr=tr["family"].values,
                Xte=Xte, yte=te["y"].values, fte=te["family"].values,
                cols=cols, gnames=gnames, gidx=gidx)


def group_sum(phi, gidx, G):
    """Sum column-level attributions (n x d) into feature groups (n x G)."""
    out = np.zeros((phi.shape[0], G))
    np.add.at(out.T, gidx, phi.T)
    return out


if __name__ == "__main__":
    for n in ["nslkdd", "unsw"]:
        d = load(n)
        print(n, d["Xtr"].shape, d["Xte"].shape, len(d["gnames"]),
              "attack frac tr/te %.3f/%.3f" % (d["ytr"].mean(), d["yte"].mean()))
        print(pd.Series(d["ftr"]).value_counts().to_dict())
