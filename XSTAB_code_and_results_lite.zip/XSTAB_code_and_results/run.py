"""Train model pools and store attributions. Resumable: one .npz per member.

Regimes (per dataset x family):
  seed    : fixed training subsample S0, seeds 0..9 (pure optimisation randomness)
  retrain : 32 members, each with its own subsample (data refresh) and seed
  shift   : attack-mix shift levels lam in {0.25,0.5,0.75,1.0}, 5 members each;
            attack-family proportions p_lam = (1-lam) p_orig + lam * uniform
Usage: python3 run.py [dataset ...]
"""
import os, sys, json, time
import numpy as np
from data import load, group_sum
from models import FAMILIES, train, attribute, logit_of
from sklearn.metrics import f1_score, accuracy_score, roc_auc_score

OUT = "/home/claude/xstab/results/members"
N_TRAIN = 40000
N_EXP = 500
os.makedirs(OUT, exist_ok=True)


def specs():
    s = [("seed", i, 0.0) for i in range(10)]
    s += [("retrain", i, 0.0) for i in range(32)]
    s += [("shift", 100 * int(l * 100) + i, l) for l in (0.25, 0.5, 0.75, 1.0) for i in range(5)]
    s += [("shiftcap", 20000 + i, 1.0) for i in range(5)]
    return s


def prepare(ds):
    d = load(ds)
    rng = np.random.default_rng(0)
    n = len(d["ytr"])
    hold = rng.choice(n, size=n // 10, replace=False)
    pool = np.setdiff1d(np.arange(n), hold)
    # explanation sets: balanced test sample, balanced in-distribution holdout
    def bal(y, idx, k, r):
        a = idx[y[idx] == 1]; b = idx[y[idx] == 0]
        return np.concatenate([r.choice(b, k // 2, replace=False), r.choice(a, k // 2, replace=False)])
    e_te = bal(d["yte"], np.arange(len(d["yte"])), N_EXP, np.random.default_rng(1))
    e_in = bal(d["ytr"], hold, N_EXP, np.random.default_rng(2))
    d.update(pool=pool, e_te=e_te, e_in=e_in, xbar_pool=d["Xtr"][pool].mean(0).astype(float))
    return d


def subsample(d, seed, lam, cap=False):
    """Training subsample of size N_TRAIN from the pool, keeping the original
    attack fraction; under shift, attack families are resampled to the mix p_lam."""
    r = np.random.default_rng(10_000 + seed)
    pool, y, fam = d["pool"], d["ytr"], d["ftr"]
    n_att = int(round(N_TRAIN * y[pool].mean())); n_nor = N_TRAIN - n_att
    nor = r.choice(pool[y[pool] == 0], n_nor, replace=False)
    att_pool = pool[y[pool] == 1]
    if lam == 0.0:
        att = r.choice(att_pool, n_att, replace=False)
        mix = None
    else:
        fams = sorted(set(fam[att_pool]))
        p0 = np.array([(fam[att_pool] == f).mean() for f in fams])
        p = (1 - lam) * p0 + lam / len(fams)
        cnt = r.multinomial(n_att, p)
        avail = np.array([(fam[att_pool] == f).sum() for f in fams])
        if cap:
            # no-duplication control: same attack total, but no family may exceed
            # its pool size; the excess is redistributed to the other families in
            # proportion to p (iterated), so the achieved mix is the closest
            # duplication-free mix to p_lam and the training size is unchanged
            target = p * n_att
            capped = np.zeros(len(fams), bool)
            for _ in range(len(fams)):
                over = (target > avail) & ~capped
                if not over.any():
                    break
                capped |= over
                target[capped] = avail[capped]
                rest = n_att - target[capped].sum()
                target[~capped] = rest * p[~capped] / p[~capped].sum()
            cnt = np.floor(target).astype(int)
            cnt[np.argmax(np.where(capped, -1, target))] += n_att - cnt.sum()
            p = cnt / cnt.sum()
        att = np.concatenate([r.choice(att_pool[fam[att_pool] == f], c,
                                       replace=c > a)
                              for f, c, a in zip(fams, cnt, avail)])
        mix = dict(fams=fams, p0=p0.tolist(), p=p.tolist(), n_att=int(len(att)),
                   n_unique_att=int(len(np.unique(att))))
    idx = np.concatenate([nor, att])
    return idx, mix


def run_member(d, ds, fam, regime, seed, lam, S0):
    path = f"{OUT}/{ds}_{fam}_{regime}_{seed:05d}.npz"
    if os.path.exists(path):
        return
    t0 = time.time()
    if regime == "seed":
        idx, mix = S0, None
    else:
        idx, mix = subsample(d, seed, lam, cap=(regime == "shiftcap"))
    X, y = d["Xtr"][idx], d["ytr"][idx]
    m = train(fam, X, y, seed)
    t_train = time.time() - t0
    xbar = d["xbar_pool"]          # common attribution baseline for all members (exact Eq. 7)
    G = len(d["gnames"])
    out = {}
    for name, Xe in (("te", d["Xte"][d["e_te"]]), ("in", d["Xtr"][d["e_in"]])):
        phi = attribute(fam, m, Xe, xbar)
        out[f"phi_{name}"] = group_sum(phi, d["gidx"], G).astype(np.float32)
        # completeness: sum(phi) vs f(x) - f(baseline) (IG/LR) or f(x) - E f (TreeSHAP)
        fx = logit_of(fam, m, Xe)
        if fam in ("lr", "mlp"):
            ref = logit_of(fam, m, xbar[None, :])[0]
        else:
            ref = float(np.mean(fx - phi.sum(1)))   # expected value implied
        out[f"compl_{name}"] = float(np.abs(phi.sum(1) - (fx - ref)).mean())
        out[f"fx_{name}"] = fx.astype(np.float32)
    proba = m.predict_proba(d["Xte"])[:, 1]
    pred = (proba >= 0.5).astype(int)
    meta = dict(ds=ds, fam=fam, regime=regime, seed=seed, lam=lam, mix=mix, n_train=int(len(idx)),
                acc=accuracy_score(d["yte"], pred), f1=f1_score(d["yte"], pred),
                auc=roc_auc_score(d["yte"], proba), t_train=t_train,
                t_total=time.time() - t0,
                compl_te=out["compl_te"], compl_in=out["compl_in"])
    np.savez_compressed(path, phi_te=out["phi_te"], phi_in=out["phi_in"],
                        fx_te=out["fx_te"], fx_in=out["fx_in"],
                        pred_te=pred.astype(np.int8), proba_te=proba.astype(np.float32),
                        meta=json.dumps(meta))
    print(json.dumps({k: meta[k] for k in ("ds", "fam", "regime", "seed", "acc", "f1", "t_total", "compl_te")}), flush=True)


if __name__ == "__main__":
    dss = sys.argv[1:] or ["nslkdd", "unsw"]
    fams = os.environ.get("FAMS", ",".join(FAMILIES)).split(",")
    for ds in dss:
        d = prepare(ds)
        np.savez(f"{OUT}/../{ds}_sets.npz", e_te=d["e_te"], e_in=d["e_in"],
                 yte_e=d["yte"][d["e_te"]], fte_e=d["fte"][d["e_te"]].astype(str),
                 gnames=np.array(d["gnames"]))
        S0, _ = subsample(d, 999, 0.0)
        for fam in fams:
            for regime, seed, lam in specs():
                run_member(d, ds, fam, regime, seed, lam, S0)
    print("DONE", flush=True)
