"""Revised results figures from results/analysis2.json. File names match figure numbers."""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 7.5,
                     "axes.linewidth": 0.6, "axes.edgecolor": "#52514e", "xtick.color": "#52514e",
                     "ytick.color": "#52514e", "legend.frameon": False, "axes.spines.top": False,
                     "axes.spines.right": False, "mathtext.fontset": "dejavuserif"})
A = json.load(open("/home/claude/xstab/results/analysis2.json"))
FIG = "/home/claude/xstab/figures"
FAMS = ["lr", "rf", "hgb", "mlp"]
LAB = {"lr": "LR", "rf": "RF", "hgb": "HGB", "mlp": "MLP"}
COL = {"lr": "#2a78d6", "rf": "#eb6834", "hgb": "#1baf7a", "mlp": "#eda100"}
MK = {"lr": "o", "rf": "s", "hgb": "^", "mlp": "D"}
LS = {"lr": "-", "rf": "--", "hgb": "-.", "mlp": ":"}
DSL = {"nslkdd": "NSL-KDD", "unsw": "UNSW-NB15"}
GRID = "#e4e3df"; INK2 = "#52514e"


def style(ax):
    ax.grid(axis="y", color=GRID, lw=0.5); ax.set_axisbelow(True)


# ---------------- Fig. 2: attack-mix shift, one panel per dataset x family
fig, axes = plt.subplots(2, 4, figsize=(7.2, 3.7), sharey=True)
for r, ds in enumerate(["nslkdd", "unsw"]):
    for c, fam in enumerate(FAMS):
        ax = axes[r, c]; sc = A["shift"][f"{ds}/{fam}"]
        lams = ["0.0", "0.25", "0.5", "0.75", "1.0"]
        x = [sc[l]["js"] for l in lams]; y = [sc[l]["jac5"] for l in lams]
        lo = [sc[l]["jac5"] - sc[l]["ci"][0] for l in lams]; hi = [sc[l]["ci"][1] - sc[l]["jac5"] for l in lams]
        ax.errorbar(x, y, yerr=[lo, hi], color=COL[fam], marker=MK[fam], ms=3.5, lw=1.3, capsize=2, elinewidth=0.7,
                    label="shifted vs. original")
        ax.plot(x, [sc[l]["within"] for l in lams], color=INK2, ls=":", lw=1.0, marker=".", ms=3,
                label="within the same mix")
        cp = sc["cap"]
        ax.errorbar([cp["js"]], [cp["jac5"]], yerr=[[cp["jac5"] - cp["ci"][0]], [cp["ci"][1] - cp["jac5"]]],
                    color="#0b0b0b", marker="*", ms=7, ls="none", capsize=2, elinewidth=0.7, label="no-duplication control")
        ax.set_ylim(0.2, 1.0); style(ax)
        if r == 0:
            ax.set_title(LAB[fam], fontsize=8)
        if c == 0:
            ax.set_ylabel(f"{DSL[ds]}\nlocal $J_5$")
        if r == 1:
            ax.set_xlabel("JS divergence (bits)")
h, l = axes[0, 0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=3, fontsize=7.5, bbox_to_anchor=(0.5, 1.04))
fig.tight_layout(w_pad=0.4, h_pad=0.6)
fig.savefig(f"{FIG}/fig2_shift.png", dpi=300, bbox_inches="tight"); plt.close(fig)

# ---------------- Fig. 3: cross-family agreement; lower triangle native explainers, upper triangle shared occlusion
fig, axes = plt.subplots(1, 2, figsize=(5.6, 2.6))
for ax, ds in zip(axes, ["nslkdd", "unsw"]):
    M = np.full((4, 4), np.nan)
    for i, a in enumerate(FAMS):
        for j, b in enumerate(FAMS):
            if i == j:
                M[i, j] = A["tab"][f"{ds}/{a}"]["retrain"]["jac5"]
            elif i > j:
                key = f"{b}-{a}" if f"{b}-{a}" in A["rash"][ds] else f"{a}-{b}"
                M[i, j] = A["rash"][ds][key]["jac5"]
            else:
                oc = A.get("occ", {}).get(ds, {})
                key = f"{a}-{b}" if f"{a}-{b}" in oc else f"{b}-{a}"
                M[i, j] = oc.get(key, np.nan)
    im = ax.imshow(M, vmin=0, vmax=1, cmap="Blues")
    for i in range(4):
        for j in range(4):
            if not np.isnan(M[i, j]):
                ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center", fontsize=7,
                        color="white" if M[i, j] > 0.6 else "#0b0b0b",
                        fontweight="bold" if i == j else "normal")
    ax.set_xticks(range(4)); ax.set_yticks(range(4))
    ax.set_xticklabels([LAB[f] for f in FAMS]); ax.set_yticklabels([LAB[f] for f in FAMS])
    ax.set_title(DSL[ds], fontsize=8)
    for s in ax.spines.values(): s.set_visible(False)
cb = fig.colorbar(im, ax=axes, fraction=0.03, pad=0.03); cb.set_label("mean local $J_5$", fontsize=7); cb.outline.set_visible(False)
fig.savefig(f"{FIG}/fig3_rashomon.png", dpi=300, bbox_inches="tight"); plt.close(fig)

# ---------------- Fig. 4: top-1 flip rate by prediction-margin quartile (retrain pairs, 95% CI)
fig, axes = plt.subplots(1, 2, figsize=(6.4, 2.4), sharey=True)
for ax, ds in zip(axes, ["nslkdd", "unsw"]):
    for fam in FAMS:
        mb = A["margin"][f"{ds}/{fam}"]
        y = [b["flip"] for b in mb]
        ax.errorbar(np.arange(4) + (FAMS.index(fam) - 1.5) * 0.06, y,
                    yerr=[[b["flip"] - b["ci"][0] for b in mb], [b["ci"][1] - b["flip"] for b in mb]],
                    color=COL[fam], marker=MK[fam], ls=LS[fam], ms=3.5, lw=1.2, capsize=2, elinewidth=0.7, label=LAB[fam])
    ax.set_xticks(range(4)); ax.set_xticklabels(["Q1\n(borderline)", "Q2", "Q3", "Q4\n(confident)"])
    ax.set_title(DSL[ds], fontsize=8); style(ax); ax.set_ylim(0, 0.8)
axes[0].set_ylabel("top-1 flip rate (retrain pairs)")
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=4, fontsize=7.5, bbox_to_anchor=(0.5, 1.07))
fig.tight_layout(w_pad=0.8)
fig.savefig(f"{FIG}/fig4_margin.png", dpi=300, bbox_inches="tight"); plt.close(fig)

# ---------------- Fig. 5: STAX within generation (left) and across generations (right)
fig, axes = plt.subplots(1, 4, figsize=(7.2, 2.4))
Ks = [1, 2, 4, 8, 16]
for c, ds in enumerate(["nslkdd", "unsw"]):
    ax = axes[c]
    for fam in FAMS:
        st = A["stax"][f"{ds}/{fam}"]
        y = [st[str(K)]["jac5"] for K in Ks]; e = [st[str(K)].get("jac5_sd", 0) for K in Ks]
        ax.errorbar(Ks, y, yerr=e, marker=MK[fam], ls=LS[fam], color=COL[fam], ms=3.5, lw=1.2, capsize=2, elinewidth=0.6, label=LAB[fam])
    ax.set_xscale("log", base=2); ax.set_xticks(Ks); ax.set_xticklabels(Ks)
    ax.set_xlabel("ensemble size $K$"); ax.set_title(f"{DSL[ds]}: same mix", fontsize=8); ax.set_ylim(0.3, 1.0); style(ax)
    ax2 = axes[2 + c]
    K5 = [1, 2, 3, 4, 5]
    for fam in FAMS:
        xg = A["xgen"][f"{ds}/{fam}"]
        ax2.plot(K5, [xg["0.0"][str(K)]["jac5"] for K in K5], marker=MK[fam], ls="-", color=COL[fam], ms=3.5, lw=1.2)
        ax2.plot(K5, [xg["1.0"][str(K)]["jac5"] for K in K5], marker=MK[fam], ls=":", color=COL[fam], ms=3.5, lw=1.2, mfc="white")
    ax2.set_xticks(K5); ax2.set_xlabel("ensemble size $K$"); ax2.set_ylim(0.3, 1.0); style(ax2)
    ax2.set_title(f"{DSL[ds]}: across mixes", fontsize=8)
axes[0].set_ylabel("$J_5$ between two ensembles")
from matplotlib.lines import Line2D
h, l = axes[0].get_legend_handles_labels()
h += [Line2D([], [], color=INK2, ls="-"), Line2D([], [], color=INK2, ls=":", marker="o", mfc="white", ms=3.5)]
l += ["original vs original", "original vs λ = 1"]
fig.legend(h, l, loc="upper center", ncol=6, fontsize=7, bbox_to_anchor=(0.5, 1.07))
fig.tight_layout(w_pad=0.5)
fig.savefig(f"{FIG}/fig5_stax.png", dpi=300, bbox_inches="tight"); plt.close(fig)
print("figures written")
