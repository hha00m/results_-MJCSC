"""Faithfulness, smoothing baseline and shared-explainer ablation.

Members retrain-0..7 of every family are re-trained deterministically (same
subsample, same seed) and checked against the stored attributions. Then:

  AOPC deletion test (Eq. 11): the top-k features (k = 1..5) of a ranking are
  replaced by a reference value (numeric: pool mean; categorical: the modal
  category, so the input stays on the one-hot manifold) and the movement of the
  output towards the threshold is averaged over k.
    own    : model's own attribution ranking
    stale  : ranking of a different retrained member (all 56 ordered pairs)
    random : random order
    ens / ens_single : K=8 ensemble explained by its own ranking / by one member's
  Smoothing baseline: SmoothGrad-style averaging of attributions over 8 Gaussian
  perturbations of the numeric inputs (sigma = 0.1 s.d.).
  Shared explainer: occlusion attribution in log-odds space for every family,
  phi_g = logit f(x) - logit f(x with group g set to reference), on all 500 flows.
Results are written per (dataset, family) so the job is resumable.
"""
import json, os, sys, itertools
import numpy as np
from data import group_sum
from models import train, attribute, logit_of
from metrics import pair_metrics
import run

N_FAITH = 200
KMAX = 5
RES = "/home/claude/xstab/results"


def logodds(fam, models, X):
    out = np.mean([logit_of(fam, m, X) for m in models], axis=0)
    if fam == "rf":
        p = np.clip(out, 1e-4, 1 - 1e-4)
        return np.log(p / (1 - p))
    return out


def out_fn(fam, models, X):
    return np.mean([logit_of(fam, m, X) for m in models], axis=0)


def reference(d):
    X = d["Xtr"][d["pool"]]
    ref = X.mean(0).astype(float)
    for g in range(len(d["gnames"])):
        cols = np.where(d["gidx"] == g)[0]
        if len(cols) > 1:                       # one-hot group -> modal category
            ref[cols] = 0.0
            ref[cols[np.argmax(X[:, cols].sum(0))]] = 1.0
    return ref


def aopc(fam, models, Xe, rank, ref, gidx, thr):
    f0 = out_fn(fam, models, Xe)
    s = np.sign(f0 - thr)
    drops = []
    Xd = Xe.copy()
    for k in range(KMAX):
        g = rank[:, k]
        mask = gidx[None, :] == g[:, None]
        Xd = np.where(mask, ref[None, :], Xd)
        drops.append((f0 - out_fn(fam, models, Xd)) * s)
    return np.mean(drops, axis=0)


def occlusion(fam, m, X, ref, gidx, G):
    base = logodds(fam, [m], X)
    phi = np.zeros((len(X), G))
    for g in range(G):
        Xg = X.copy(); cols = gidx == g
        Xg[:, cols] = ref[cols]
        phi[:, g] = base - logodds(fam, [m], Xg)
    return phi


def main(ds):
    d = run.prepare(ds)
    Xe_all = d["Xte"][d["e_te"]].astype(float)
    sel = np.random.default_rng(3).choice(len(Xe_all), N_FAITH, replace=False)
    Xe = Xe_all[sel]
    G = len(d["gnames"]); gidx = d["gidx"]
    ref = reference(d)
    num = np.array([not c.count("=") for c in d["cols"]])
    for fam in ["lr", "rf", "hgb", "mlp"]:
        fp = f"{RES}/faith_{ds}_{fam}.json"
        if os.path.exists(fp):
            continue
        thr = 0.5 if fam == "rf" else 0.0
        models, phis, repro, smooth, occ = [], [], [], [], []
        for i in range(8):
            idx, _ = run.subsample(d, i, 0.0)
            m = train(fam, d["Xtr"][idx], d["ytr"][idx], i)
            phi = group_sum(attribute(fam, m, Xe_all, d["xbar_pool"]), gidx, G)
            stored = np.load(f"{run.OUT}/{ds}_{fam}_retrain_{i:05d}.npz")["phi_te"]
            repro.append(float(np.abs(phi - stored).max()))
            models.append(m); phis.append(phi[sel])
            nr = np.random.default_rng(100 + i); acc_s = np.zeros((len(Xe), G))
            for _ in range(8):
                Xn = Xe.copy(); Xn[:, num] += nr.normal(0, 0.1, (len(Xn), num.sum()))
                acc_s += group_sum(attribute(fam, m, Xn, d["xbar_pool"]), gidx, G)
            smooth.append(acc_s / 8)
            occ.append(occlusion(fam, m, Xe_all, ref, gidx, G).astype(np.float32))
        rng = np.random.default_rng(4)
        rk = lambda P: np.argsort(-np.abs(P), axis=1)
        own = np.array([aopc(fam, [models[i]], Xe, rk(phis[i]), ref, gidx, thr) for i in range(8)])
        stale = {(i, j): aopc(fam, [models[i]], Xe, rk(phis[j]), ref, gidx, thr)
                 for i in range(8) for j in range(8) if i != j}
        rnd = [aopc(fam, [models[i]], Xe, np.array([rng.permutation(G) for _ in range(N_FAITH)]), ref, gidx, thr).mean()
               for i in range(8)]
        Phi = np.mean(phis, axis=0)
        ens = aopc(fam, models, Xe, rk(Phi), ref, gidx, thr)
        ens_single = np.array([aopc(fam, models, Xe, rk(phis[i]), ref, gidx, thr) for i in range(8)])
        ratio_pairs = [stale[(i, j)].mean() / own[i].mean() for (i, j) in stale]
        diff = np.array([own[i] - stale[(i, j)] for (i, j) in stale]).mean(0)
        br = np.random.default_rng(5)
        boots = [diff[br.integers(0, len(diff), len(diff))].mean() for _ in range(2000)]
        rel = diff / own.mean()
        bootr = [rel[br.integers(0, len(rel), len(rel))].mean() for _ in range(2000)]
        pr = list(itertools.combinations(range(8), 2))
        res = dict(
            own=float(own.mean()), stale=float(np.mean([v.mean() for v in stale.values()])),
            random=float(np.mean(rnd)), ens=float(ens.mean()), ens_single=float(ens_single.mean()),
            stale_ratio=float(np.mean(ratio_pairs)), stale_ratio_min=float(np.min(ratio_pairs)),
            loss_ci=[float(np.percentile(bootr, 2.5)), float(np.percentile(bootr, 97.5))],
            own_minus_stale=float(diff.mean()),
            smooth=dict(jac5_raw=float(np.mean([pair_metrics(phis[a], phis[b])["jac5"] for a, b in pr])),
                        jac5_smooth=float(np.mean([pair_metrics(smooth[a], smooth[b])["jac5"] for a, b in pr]))),
            repro_maxdiff=float(max(repro)))
        np.save(f"{RES}/occ_{ds}_{fam}.npy", np.stack(occ))
        json.dump(res, open(fp, "w"))
        print(ds, fam, json.dumps(res), flush=True)


if __name__ == "__main__":
    for ds in sys.argv[1:]:
        main(ds)
