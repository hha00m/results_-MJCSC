"""Revised analysis (after internal review). Writes results/analysis2.json.

Changes vs. analyze.py: all-pairs estimators with member-level (cluster)
bootstrap CIs; k-sensitivity; same-estimator shift curves with within-lambda
controls and a no-duplication (capped) shift control; input-shift noise floor;
quantile margin bins on retrain pairs with CIs; 200 STAX partitions; cross-
generation STAX (bias floor); certificate with matched-coverage baselines,
50 partitions and a cross-generation check; shared-explainer (occlusion)
cross-family ablation.
"""
import glob, json, itertools, os, sys
import numpy as np
from scipy.stats import kendalltau
from metrics import pair_metrics, local_topk_jaccard, local_top1_agree, topk_idx, global_imp, K_TOP

RES = "/home/claude/xstab/results"
DS = ["nslkdd", "unsw"]; FAMS = ["lr", "rf", "hgb", "mlp"]
LAMS = [0.25, 0.5, 0.75, 1.0]
rng = np.random.default_rng(0)
NBOOT = 1000


def load():
    M = {}
    for p in sorted(glob.glob(f"{RES}/members/*.npz")):
        z = np.load(p); meta = json.loads(str(z["meta"]))
        M.setdefault((meta["ds"], meta["fam"], meta["regime"]), []).append(dict(
            meta=meta, phi=z["phi_te"].astype(float), phi_in=z["phi_in"].astype(float),
            pred=z["pred_te"], proba=z["proba_te"].astype(float)))
    for k in M:
        M[k].sort(key=lambda m: m["meta"]["seed"])
    return M


KEYS = ["jac5", "top1", "rho", "sign", "g_tau", "g_jac5", "pred_agree"]


def pair_matrix(L):
    n = len(L); out = {k: np.full((n, n), np.nan) for k in KEYS}
    for i, j in itertools.combinations(range(n), 2):
        m = pair_metrics(L[i]["phi"], L[j]["phi"])
        m["pred_agree"] = float((L[i]["pred"] == L[j]["pred"]).mean())
        for k in KEYS:
            out[k][i, j] = out[k][j, i] = m[k]
    return out


def mean_offdiag(Mx, idx=None):
    if idx is None:
        idx = np.arange(Mx.shape[0])
    a, b = np.meshgrid(idx, idx, indexing="ij")
    keep = a != b
    return float(np.nanmean(Mx[a[keep], b[keep]]))


def cluster_ci(Mx):
    n = Mx.shape[0]
    bs = [mean_offdiag(Mx, rng.integers(0, n, n)) for _ in range(NBOOT)]
    return [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]


def two_sample(A, B, metric="jac5"):
    """mean metric over all (a in A, b in B) pairs, + cluster bootstrap over both sides"""
    Mx = np.array([[pair_metrics(a["phi"], b["phi"])[metric] for b in B] for a in A])
    bs = []
    for _ in range(NBOOT):
        ia = rng.integers(0, len(A), len(A)); ib = rng.integers(0, len(B), len(B))
        bs.append(Mx[np.ix_(ia, ib)].mean())
    return float(Mx.mean()), [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))], Mx


def ens(L, idx):
    return np.mean([L[i]["phi"] for i in idx], axis=0)


def certify(S, rng, B=200, delta=0.1, k=K_TOP):
    K, n, G = S.shape
    cnt = np.zeros((n, G)); r = np.arange(n)[:, None]
    for _ in range(B):
        t = topk_idx(S[rng.integers(0, K, K)].mean(0), k)
        hit = np.zeros((n, G)); hit[r, t] = 1; cnt += hit
    return S.mean(0), cnt / B


def topmask(P, k=K_TOP):
    n, G = P.shape; m = np.zeros((n, G), bool); m[np.arange(n)[:, None], topk_idx(P, k)] = True
    return m


def cert_eval(Phi, P, ref_phi, delta=0.1, k=K_TOP):
    """precision of STAX certificate vs matched-coverage baselines, against a reference ensemble"""
    n, G = Phi.shape
    topA = topmask(Phi, k); inR = topmask(ref_phi, k)
    C = topA & (P >= 1 - delta)
    c = C.sum(1)
    order = np.argsort(-np.abs(Phi), axis=1)
    rankC = np.zeros_like(C)
    for i in range(n):
        rankC[i, order[i, :c[i]]] = True
    a = np.sort(np.abs(Phi), axis=1)[:, ::-1]
    gap = (np.abs(Phi) - a[:, [k]]) / (a[:, [0]] + 1e-12)
    gap = np.where(topA, gap, -np.inf)
    thr = np.sort(gap[topA])[::-1][max(C.sum() - 1, 0)] if C.sum() > 0 else np.inf
    gapC = gap >= thr
    unc = topA & ~C
    # fixed-count baseline: same total number certified, spread evenly over flows (top-m everywhere)
    tot = int(C.sum()); m0 = tot // n; extra = tot - m0 * n
    cnts = np.full(n, m0); cnts[np.random.default_rng(7).choice(n, extra, replace=False)] += 1
    fixC = np.zeros_like(C)
    for i in range(n):
        fixC[i, order[i, :cnts[i]]] = True
    return dict(prec=float(inR[C].mean()), prec_rank=float(inR[rankC].mean()), prec_gap=float(inR[gapC].mean()),
                prec_fixed=float(inR[fixC].mean()),
                prec_unc=float(inR[unc].mean()) if unc.any() else float("nan"),
                prec_all=float(inR[topA].mean()), cov=float(C.sum() / topA.sum()),
                cov_gap=float(gapC.sum() / topA.sum()))


def main():
    M = load()
    out = {k: {} for k in ["tab", "ksens", "shift", "inshift", "rash", "occ", "margin", "classes",
                            "stax", "xgen", "cert", "certx", "ensacc", "acc", "mix", "compl"]}
    for ds in DS:
        sets = np.load(f"{RES}/{ds}_sets.npz", allow_pickle=True)
        fte = sets["fte_e"]; e_te = sets["e_te"]
        yfull = np.load(f"{RES}/{ds}_yte.npy")
        out.setdefault("gnames", {})[ds] = list(sets["gnames"])
        for fam in FAMS:
            key = f"{ds}/{fam}"
            seed = M[(ds, fam, "seed")]; ret = M[(ds, fam, "retrain")]; sh = M[(ds, fam, "shift")]; cap = M[(ds, fam, "shiftcap")]
            acc = lambda L: [m["meta"]["acc"] for m in L]
            out["acc"][key] = dict(retrain=float(np.mean(acc(ret))), retrain_sd=float(np.std(acc(ret))),
                                   **{f"shift_{l}": float(np.mean([m["meta"]["acc"] for m in sh if m["meta"]["lam"] == l])) for l in LAMS},
                                   shiftcap=float(np.mean(acc(cap))))
            out["compl"][key] = float(np.max([m["meta"]["compl_te"] for m in seed + ret]))
            # ---- Table 3: all pairs + cluster CIs
            Ms, Mr = pair_matrix(seed), pair_matrix(ret)
            t = {}
            for reg, Mx in (("seed", Ms), ("retrain", Mr)):
                t[reg] = {k: mean_offdiag(Mx[k]) for k in KEYS}
                t[reg]["ci"] = {k: cluster_ci(Mx[k]) for k in ("jac5", "top1")}
            out["tab"][key] = t
            # ---- k sensitivity (retrain, all pairs)
            ks = {}
            for kk in (1, 3, 5, 10):
                ks[str(kk)] = float(np.mean([local_topk_jaccard(ret[i]["phi"], ret[j]["phi"], kk).mean()
                                             for i, j in itertools.combinations(range(len(ret)), 2)]))
            out["ksens"][key] = ks
            # ---- shift: refs = retrain 0..9; lam0 = retrain 10..14 (same estimator)
            refs, lam0 = ret[:10], ret[10:15]
            sc = {}
            v, ci, Mx0 = two_sample(lam0, refs)
            within0 = mean_offdiag(pair_matrix(lam0)["jac5"])
            sc["0.0"] = dict(jac5=v, ci=ci, within=within0, js=0.0, acc=float(np.mean(acc(lam0))))
            permember = [(0.0, Mx0[i].mean()) for i in range(5)]
            for lam in LAMS:
                L = [m for m in sh if m["meta"]["lam"] == lam]
                v, ci, Mx = two_sample(L, refs)
                tp = two_sample(L, refs, "top1")[0]; gt = two_sample(L, refs, "g_tau")[0]
                mix = L[0]["meta"]["mix"]; p0, p = np.array(mix["p0"]), np.array(mix["p"]); mm = (p0 + p) / 2
                js = 0.5 * np.sum(p0 * np.log2(p0 / mm)) + 0.5 * np.sum(p * np.log2(p / mm))
                sc[str(lam)] = dict(jac5=v, ci=ci, top1=tp, g_tau=gt, within=mean_offdiag(pair_matrix(L)["jac5"]),
                                    js=float(js), acc=float(np.mean(acc(L))))
                permember += [(js, Mx[i].mean()) for i in range(5)]
            # trend: OLS slope of member-level J5 on JS, bootstrap over members
            pm = np.array(permember)
            slope = np.polyfit(pm[:, 0], pm[:, 1], 1)[0]
            bs = []
            for _ in range(NBOOT):
                b = pm[rng.integers(0, len(pm), len(pm))]
                if np.ptp(b[:, 0]) > 0:
                    bs.append(np.polyfit(b[:, 0], b[:, 1], 1)[0])
            sc["slope"] = float(slope); sc["slope_ci"] = [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
            v, ci, _ = two_sample(cap, refs)
            mixc = cap[0]["meta"].get("mix") or {}
            p0c, pc = np.array(mixc["p0"]), np.array(mixc["p"]); mmc = (p0c + pc) / 2
            jsc = 0.5 * np.sum(p0c * np.log2(p0c / mmc)) + 0.5 * np.sum(np.where(pc > 0, pc * np.log2(np.where(pc > 0, pc, 1) / mmc), 0))
            sc["cap"] = dict(jac5=v, ci=ci, within=mean_offdiag(pair_matrix(cap)["jac5"]), acc=float(np.mean(acc(cap))), js=float(jsc), p=mixc["p"],
                             n_att=mixc.get("n_att"), n_unique=mixc.get("n_unique_att"), n_train=cap[0]["meta"].get("n_train"))
            if fam == "lr":
                out["mix"][ds] = {str(l): dict(n_att=[m for m in sh if m["meta"]["lam"] == l][0]["meta"]["mix"].get("n_att"),
                                               n_unique=[m for m in sh if m["meta"]["lam"] == l][0]["meta"]["mix"].get("n_unique_att"),
                                               p0=[m for m in sh if m["meta"]["lam"] == l][0]["meta"]["mix"]["p0"],
                                               p=[m for m in sh if m["meta"]["lam"] == l][0]["meta"]["mix"]["p"],
                                               fams=[m for m in sh if m["meta"]["lam"] == l][0]["meta"]["mix"]["fams"]) for l in LAMS}
            out["shift"][key] = sc
            # ---- input shift with noise floor (250 vs 250, class-balanced halves)
            h1 = np.r_[np.arange(0, 250, 2), np.arange(250, 500, 2)]; h2 = h1 + 1
            fl, sh_t, fl_j, sh_j = [], [], [], []
            for m in ret:
                gi1, gi2, gt1 = global_imp(m["phi_in"][h1]), global_imp(m["phi_in"][h2]), global_imp(m["phi"][h2])
                fl.append(kendalltau(gi1, gi2).statistic); sh_t.append(kendalltau(gi1, gt1).statistic)
                j = lambda a, b: len(set(np.argsort(-a)[:5]) & set(np.argsort(-b)[:5])) / len(set(np.argsort(-a)[:5]) | set(np.argsort(-b)[:5]))
                fl_j.append(j(gi1, gi2)); sh_j.append(j(gi1, gt1))
            out["inshift"][key] = dict(tau_floor=float(np.mean(fl)), tau_shift=float(np.mean(sh_t)),
                                       j_floor=float(np.mean(fl_j)), j_shift=float(np.mean(sh_j)),
                                       tau_retrain=t["retrain"]["g_tau"], j_retrain=t["retrain"]["g_jac5"])
            # ---- margin (quartiles) and classes, retrain all pairs
            am = np.stack([np.argmax(np.abs(m["phi"]), 1) for m in ret])        # 32 x n
            nP = len(ret) * (len(ret) - 1) / 2
            flip = np.array([1 - sum((am[:, i] == v).sum() * ((am[:, i] == v).sum() - 1) / 2
                                     for v in np.unique(am[:, i])) / nP for i in range(am.shape[1])])
            pm_ = np.mean([m["proba"][e_te] for m in ret], 0)
            marg = np.abs(pm_ - 0.5)
            q = np.quantile(marg, [0, .25, .5, .75, 1.0])
            mb = []
            for lo, hi in zip(q[:-1], q[1:]):
                s = (marg >= lo) & (marg <= hi)
                bs = [flip[s][rng.integers(0, s.sum(), s.sum())].mean() for _ in range(NBOOT)]
                mb.append(dict(lo=float(lo), hi=float(hi), n=int(s.sum()), flip=float(flip[s].mean()),
                               ci=[float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]))
            out["margin"][key] = mb
            pred_att = np.mean([m["pred"][e_te] for m in ret], 0) >= 0.5
            cl = {}
            for c in sorted(set(fte)):
                s = fte == c
                if s.sum() >= 10:
                    bs = [flip[s][rng.integers(0, s.sum(), s.sum())].mean() for _ in range(NBOOT)]
                    cl[c] = dict(n=int(s.sum()), flip=float(flip[s].mean()),
                                 ci=[float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))])
            cl["_all"] = dict(flip=float(flip.mean()), flip_predatt=float(flip[pred_att].mean()),
                              flip_prednorm=float(flip[~pred_att].mean()), n_predatt=int(pred_att.sum()))
            out["classes"][key] = cl
            # ---- STAX within generation, 200 partitions
            st = {"1": dict(jac5=t["retrain"]["jac5"], top1=t["retrain"]["top1"], g_tau=t["retrain"]["g_tau"])}
            for K in (2, 4, 8, 16):
                ms = []
                for _ in range(200):
                    pmu = rng.permutation(len(ret)); ms.append(pair_metrics(ens(ret, pmu[:K]), ens(ret, pmu[K:2 * K])))
                st[str(K)] = {k: float(np.mean([d[k] for d in ms])) for k in ("jac5", "top1", "g_tau")}
                st[str(K)]["jac5_sd"] = float(np.std([d["jac5"] for d in ms]))
            out["stax"][key] = st
            # ---- cross-generation STAX: lam0 ensembles (from retrain) vs shifted ensembles
            xg = {}
            for tag, L in [("0.5", [m for m in sh if m["meta"]["lam"] == 0.5]),
                           ("1.0", [m for m in sh if m["meta"]["lam"] == 1.0]), ("cap", cap), ("0.0", ret[27:32])]:
                curve = {}
                pool0 = list(range(27)) if tag == "0.0" else list(range(32))
                for K in (1, 2, 3, 4, 5):
                    js_, d2 = [], []
                    for _ in range(100):
                        ia = rng.choice(pool0, K, replace=False); ib = rng.choice(len(L), K, replace=False)
                        A_ = ens(ret, ia); B_ = np.mean([L[i]["phi"] for i in ib], 0)
                        js_.append(local_topk_jaccard(A_, B_).mean()); d2.append(((A_ - B_) ** 2).sum(1).mean())
                    curve[str(K)] = dict(jac5=float(np.mean(js_)), d2=float(np.mean(d2)))
                # fit d2 = a + b/K
                Ks = np.array([1, 2, 3, 4, 5]); y = np.array([curve[str(k)]["d2"] for k in Ks])
                X_ = np.c_[np.ones(5), 1 / Ks]; a, b = np.linalg.lstsq(X_, y, rcond=None)[0]
                curve["bias_frac_K1"] = float(a / y[0]); curve["a"] = float(a); curve["b"] = float(b)
                xg[tag] = curve
            out["xgen"][key] = xg
            # ---- certificate: 50 partitions, K in {4, 8}; matched-coverage baselines
            ce = {}
            for K in (4, 8):
                rs = []
                for _ in range(50):
                    pmu = rng.permutation(len(ret))
                    S = np.stack([ret[i]["phi"] for i in pmu[:K]])
                    Phi, P = certify(S, rng)
                    rs.append(cert_eval(Phi, P, ens(ret, pmu[K:2 * K])))
                ce[str(K)] = {k: float(np.nanmean([r[k] for r in rs])) for k in rs[0]}
            out["cert"][key] = ce
            # cross-generation certificate: certify on 5 lam0 members, check vs 5 shifted members
            cx = {}
            for tag, L in [("0.0", ret[27:32]), ("0.25", [m for m in sh if m["meta"]["lam"] == 0.25]),
                           ("0.5", [m for m in sh if m["meta"]["lam"] == 0.5])]:
                rs = []
                for _ in range(20):
                    ia = rng.choice(27, 5, replace=False)
                    Phi, P = certify(np.stack([ret[i]["phi"] for i in ia]), rng)
                    rs.append(cert_eval(Phi, P, np.mean([m["phi"] for m in L], 0)))
                cx[tag] = {k: float(np.nanmean([r[k] for r in rs])) for k in ("prec", "prec_rank", "prec_fixed", "prec_unc", "cov")}
            out["certx"][key] = cx
            # ---- ensemble accuracy
            def ens_acc(idx):
                P = np.clip(np.stack([ret[i]["proba"] for i in idx]), 1e-7, 1 - 1e-7)
                p = P.mean(0) if fam == "rf" else 1 / (1 + np.exp(-np.log(P / (1 - P)).mean(0)))
                return float(((p >= 0.5) == yfull).mean())
            ea = {}
            for K in (1, 8):
                v = [ens_acc(rng.permutation(len(ret))[:K]) for _ in range(100)]
                ea[str(K)] = dict(acc=float(np.mean(v)), lo=float(np.percentile(v, 2.5)), hi=float(np.percentile(v, 97.5)))
            out["ensacc"][key] = ea
            print(key, "J5 R %.3f %s | shift1 %.3f within %.3f cap %.3f | K8 %.3f | cert8 %.3f rank %.3f gap %.3f fixed %.3f" % (
                t["retrain"]["jac5"], t["retrain"]["ci"]["jac5"], sc["1.0"]["jac5"], sc["1.0"]["within"], sc["cap"]["jac5"],
                st["8"]["jac5"], ce["8"]["prec"], ce["8"]["prec_rank"], ce["8"]["prec_gap"], ce["8"]["prec_fixed"]), flush=True)
        # ---- Rashomon (TreeSHAP/IG/linear SHAP) and shared-explainer (occlusion) ablation
        rs = {}
        for fa, fb in itertools.combinations(FAMS, 2):
            A, B = M[(ds, fa, "retrain")], M[(ds, fb, "retrain")]
            ms = [pair_metrics(A[i]["phi"], B[i]["phi"]) for i in range(16)]
            rs[f"{fa}-{fb}"] = dict(jac5=float(np.mean([m["jac5"] for m in ms])), top1=float(np.mean([m["top1"] for m in ms])),
                                    g_tau=float(np.mean([m["g_tau"] for m in ms])),
                                    acc_gap=float(abs(np.mean([m["meta"]["acc"] for m in A]) - np.mean([m["meta"]["acc"] for m in B]))),
                                    pred_agree=float(np.mean([(A[i]["pred"] == B[i]["pred"]).mean() for i in range(16)])))
        out["rash"][ds] = rs
        occp = f"{RES}/occ_{ds}_lr.npy"
        if all(os.path.exists(f"{RES}/occ_{ds}_{f}.npy") for f in FAMS):
            O = {f: np.load(f"{RES}/occ_{ds}_{f}.npy").astype(float) for f in FAMS}
            oc = {}
            for f in FAMS:
                oc[f"{f}-{f}"] = float(np.mean([local_topk_jaccard(O[f][i], O[f][j]).mean() for i, j in itertools.combinations(range(8), 2)]))
            for fa, fb in itertools.combinations(FAMS, 2):
                oc[f"{fa}-{fb}"] = float(np.mean([local_topk_jaccard(O[fa][i], O[fb][i]).mean() for i in range(8)]))
            out["occ"][ds] = oc
        out.setdefault("top_features", {})[ds] = {
            f: [out["gnames"][ds][i] for i in np.argsort(-global_imp(np.mean([m["phi"] for m in M[(ds, f, "retrain")]], 0)))[:8]] for f in FAMS}
    out["n_members"] = len(glob.glob(f"{RES}/members/*.npz"))
    json.dump(out, open(f"{RES}/analysis2.json", "w"), indent=1)
    print("written")


if __name__ == "__main__":
    main()
