"""Attribution-stability metrics. A, B are (n x G) attribution matrices that
explain the same n instances; rankings use |attribution|."""
import numpy as np
from scipy.stats import kendalltau, rankdata

K_TOP = 5


def topk_idx(A, k=K_TOP):
    return np.argsort(-np.abs(A), axis=1)[:, :k]


def local_topk_jaccard(A, B, k=K_TOP):
    ta, tb = topk_idx(A, k), topk_idx(B, k)
    G = A.shape[1]
    ma = np.zeros((A.shape[0], G), bool); mb = np.zeros_like(ma)
    r = np.arange(A.shape[0])[:, None]
    ma[r, ta] = True; mb[r, tb] = True
    inter = (ma & mb).sum(1); union = (ma | mb).sum(1)
    return inter / union


def local_top1_agree(A, B):
    return (np.argmax(np.abs(A), 1) == np.argmax(np.abs(B), 1)).astype(float)


def local_spearman(A, B):
    ra = rankdata(-np.abs(A), axis=1); rb = rankdata(-np.abs(B), axis=1)
    ra = ra - ra.mean(1, keepdims=True); rb = rb - rb.mean(1, keepdims=True)
    den = np.sqrt((ra ** 2).sum(1) * (rb ** 2).sum(1)) + 1e-12
    return (ra * rb).sum(1) / den


def local_sign_agree(A, B, k=K_TOP):
    """Among A's top-k features, fraction whose attribution sign agrees in B
    (direction of evidence: pushes towards 'attack' or towards 'normal')."""
    t = topk_idx(A, k)
    r = np.arange(A.shape[0])[:, None]
    return (np.sign(A[r, t]) == np.sign(B[r, t])).mean(1)


def global_imp(A):
    return np.abs(A).mean(0)


def global_kendall(A, B):
    return kendalltau(global_imp(A), global_imp(B)).statistic


def global_topk_jaccard(A, B, k=K_TOP):
    a = set(np.argsort(-global_imp(A))[:k]); b = set(np.argsort(-global_imp(B))[:k])
    return len(a & b) / len(a | b)


def pair_metrics(A, B, mask=None):
    """Mean local metrics (optionally over a subset of instances) + global metrics."""
    sel = slice(None) if mask is None else mask
    return dict(
        jac5=float(local_topk_jaccard(A, B)[sel].mean()),
        top1=float(local_top1_agree(A, B)[sel].mean()),
        rho=float(local_spearman(A, B)[sel].mean()),
        sign=float(local_sign_agree(A, B)[sel].mean()),
        g_tau=float(global_kendall(A, B)),
        g_jac5=float(global_topk_jaccard(A, B)),
    )
