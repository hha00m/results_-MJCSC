#!/bin/bash
cd /home/claude/xstab
if ps -eo cmd | grep -q "^python3 run.py"; then echo running; else OMP_NUM_THREADS=1 setsid nohup python3 run.py nslkdd unsw >> results/run.log 2>&1 < /dev/null & sleep 2; echo started; fi
ps -eo pid,etimes,cmd | grep "^ *[0-9]* *[0-9]* python3 run.py"
