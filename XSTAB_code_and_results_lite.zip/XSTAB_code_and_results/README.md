# Attribution drift in intrusion detection (STAX) — code and results

Reproduces every number in "Are Intrusion Detection Explanations Stable? Measuring Attribution Drift across Retraining, Seeds and Data Shift".

1. Put KDDTrain+.txt, KDDTest+.txt, UNSW_NB15_training-set.csv, UNSW_NB15_testing-set.csv in ./data (paths in data.py).
2. `OMP_NUM_THREADS=1 python3 run.py nslkdd unsw` — trains 536 members (resumable; one .npz per member in results/members).
3. `OMP_NUM_THREADS=1 python3 faith.py nslkdd unsw` — faithfulness, smoothing baseline, occlusion attributions.
4. `python3 analyze2.py && python3 occ_summary.py` — writes results/analysis2.json.
5. `python3 make_figs2.py; python3 fig_framework.py` — figures.
6. `python3 verify_claims.py` — independent re-derivation of headline numbers.
7. `cd paper && python3 equations.py && python3 build_paper2.py` — manuscript (needs node + docx, pdflatex).

Environment: Python 3.13, NumPy 2.5, scikit-learn 1.9.1, shap 0.52.0, CPU only.
