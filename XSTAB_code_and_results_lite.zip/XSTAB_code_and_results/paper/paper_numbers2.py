"""Every number quoted in the revised prose, computed from analysis2.json and faith_*.json."""
import json, glob
import numpy as np

R = "/home/claude/xstab/results"
A = json.load(open(f"{R}/analysis2.json"))
FAMS = ["lr", "rf", "hgb", "mlp"]; DS = ["nslkdd", "unsw"]
import os
_FAKE = bool(os.environ.get("FAKE_FAITH"))
_fp = lambda ds, f: f"{R}/faith_{ds}_{f}.json" if (not _FAKE or os.path.exists(f"{R}/faith_{ds}_{f}.json")) else f"{R}/faith_nslkdd_{f}.json"
F = {ds: {f: json.load(open(_fp(ds, f))) for f in FAMS} for ds in DS}
if _FAKE:
    A.setdefault("occ", {}).setdefault("unsw", A["occ"].get("nslkdd", {}))
K = lambda d, f: f"{d}/{f}"
pct = lambda x, d=1: f"{100 * x:.{d}f}%"
f2 = lambda x: f"{x:.2f}"
rng = lambda a, b, fmt=f2: f"{fmt(a)}–{fmt(b)}"

N = {}
T = A["tab"]
N["n_members"] = str(A["n_members"])
N["G_nsl"] = str(len(A["gnames"]["nslkdd"])); N["G_unsw"] = str(len(A["gnames"]["unsw"]))
N["n_distinct"] = str(A["n_members"] - 2 * 9)          # LR seed members are identical (2 data sets x 9 duplicates)
pa = [T[K(d, f)]["retrain"]["pred_agree"] for d in DS for f in FAMS]
N["pa_min"], N["pa_max"] = pct(min(pa)), pct(max(pa))
N["intro_pred_agree"] = f"{100*min(pa):.1f}–{100*max(pa):.1f}%"
N["intro_max_acc_sd"] = f"{100*max(A['acc'][K(d, f)]['retrain_sd'] for d in DS for f in FAMS):.1f}"
rj = [T[K(d, f)]["retrain"]["jac5"] for d in DS for f in FAMS]
N["intro_ret_jac_min"], N["intro_ret_jac_max"] = f2(min(rj)), f2(max(rj))
N["intro_mlp_flip"] = pct(1 - T["nslkdd/mlp"]["seed"]["top1"], 0)
N["ci_halfwidth_max"] = f2(max((T[K(d, f)]["retrain"]["ci"]["jac5"][1] - T[K(d, f)]["retrain"]["ci"]["jac5"][0]) / 2 for d in DS for f in FAMS))
for d in DS:
    for f in FAMS:
        for reg in ("seed", "retrain"):
            for m in ("jac5", "top1", "sign", "g_tau", "g_jac5", "pred_agree", "rho"):
                N[f"{d}_{f}_{reg}_{m}"] = f2(T[K(d, f)][reg][m])
        N[f"{d}_{f}_flip_seed"] = pct(1 - T[K(d, f)]["seed"]["top1"], 0)
N["sign_min"] = pct(min(T[K(d, f)][r]["sign"] for d in DS for f in FAMS for r in ("seed", "retrain")))
N["seed_to_ret_max"] = f2(max(T[K(d, f)]["seed"]["jac5"] - T[K(d, f)]["retrain"]["jac5"] for d in DS for f in ["rf", "hgb", "mlp"]))
N["hgb_top1_min"] = f2(min(T[K(d, "hgb")]["retrain"]["top1"] for d in DS))
ks = A["ksens"]
dev = [abs(ks[K(d, f)][k] - ks[K(d, f)]["5"]) for d in DS for f in FAMS for k in ("3", "10")]
N["ksens_maxdev"] = f2(max(dev))

# shift
S = A["shift"]
for d in DS:
    for f in FAMS:
        N[f"{d}_{f}_shift1_jac5"] = f2(S[K(d, f)]["1.0"]["jac5"])
        N[f"{d}_{f}_shift0_jac5"] = f2(S[K(d, f)]["0.0"]["jac5"])
    N[f"{d}_js_max"] = f2(S[K(d, "lr")]["1.0"]["js"])
N["nsl_slopes"] = "; ".join(f"{f.upper()} {S[K('nslkdd', f)]['slope']:.2f} [{S[K('nslkdd', f)]['slope_ci'][0]:.2f}, {S[K('nslkdd', f)]['slope_ci'][1]:.2f}]" for f in FAMS)
N["nsl_within1"] = ", ".join(f"{f.upper()} {S[K('nslkdd', f)]['1.0']['within']:.2f} vs {S[K('nslkdd', f)]['0.0']['within']:.2f}" for f in FAMS)
N["nsl_cap_js"] = f2(S["nslkdd/lr"]["cap"]["js"]); N["unsw_cap_js"] = f2(S["unsw/lr"]["cap"]["js"])
N["nsl_cap_summary"] = ", ".join(f"{f.upper()} {S[K('nslkdd', f)]['cap']['jac5']:.2f} vs {S[K('nslkdd', f)]['0.0']['jac5']:.2f}" for f in FAMS)
N["unsw_hgb_l0"] = f2(S["unsw/hgb"]["0.0"]["jac5"]); N["unsw_hgb_cap"] = f2(S["unsw/hgb"]["cap"]["jac5"])
mix = A["mix"]["nslkdd"]["1.0"]
N["nsl_unique1"] = f"{mix['n_unique']:,}"; N["nsl_natt"] = f"{mix['n_att']:,}"
dacc = lambda d, f, l: A["acc"][K(d, f)][f"shift_{l}"] - A["acc"][K(d, f)]["retrain"]
N["unsw_shift_dacc_max"] = f"{100*max(abs(dacc('unsw', f, l)) for f in FAMS for l in ['0.25', '0.5', '0.75', '1.0']):.1f}"
N["nsl_lr_dacc"] = f"{100*dacc('nslkdd', 'lr', '1.0'):.1f}"
N["nsl_lr_dacc_sd"] = f"{dacc('nslkdd', 'lr', '1.0') / A['acc']['nslkdd/lr']['retrain_sd']:.0f}"
N["unsw_hgb_shift_loss"] = f2(S["unsw/hgb"]["0.0"]["jac5"] - S["unsw/hgb"]["1.0"]["jac5"])
N["unsw_lr_shift_loss"] = f2(S["unsw/lr"]["0.0"]["jac5"] - S["unsw/lr"]["1.0"]["jac5"])
N["unsw_mlp_slope_ci"] = f"[{S['unsw/mlp']['slope_ci'][0]:.2f}, {S['unsw/mlp']['slope_ci'][1]:.2f}]"
I = A["inshift"]
N["inshift_tau_shift_rng"] = rng(min(I[K(d, f)]["tau_shift"] for d in DS for f in FAMS), max(I[K(d, f)]["tau_shift"] for d in DS for f in FAMS))
N["inshift_tau_floor_rng"] = rng(min(I[K(d, f)]["tau_floor"] for d in DS for f in FAMS), max(I[K(d, f)]["tau_floor"] for d in DS for f in FAMS))
N["nsl_hgb_jret"] = f2(I["nslkdd/hgb"]["j_retrain"]); N["nsl_hgb_jshift"] = f2(I["nslkdd/hgb"]["j_shift"])
assert all(I[K(d, f)]["tau_shift"] < I[K(d, f)]["tau_floor"] for d in DS for f in FAMS)
assert all(I[K(d, f)]["tau_retrain"] < I[K(d, f)]["tau_shift"] for d in DS for f in FAMS)

# Rashomon + occlusion
Rr = A["rash"]
N["rash_jac_min"] = f2(min(v["jac5"] for d in DS for v in Rr[d].values()))
N["rash_jac_max"] = f2(max(v["jac5"] for d in DS for v in Rr[d].values()))
N["rash_pa_min"] = pct(min(v["pred_agree"] for d in DS for v in Rr[d].values()))
N["rash_pa_max"] = pct(max(v["pred_agree"] for d in DS for v in Rr[d].values()))
N["rash_accgap_max"] = f"{100*max(v['acc_gap'] for d in DS for v in Rr[d].values()):.1f}"
N["nsl_rf_hgb_top1"] = f2(Rr["nslkdd"]["rf-hgb"]["top1"]); N["unsw_rf_hgb_top1"] = f2(Rr["unsw"]["rf-hgb"]["top1"])
O = A["occ"]
cross = [v for d in DS for k, v in O[d].items() if k.split("-")[0] != k.split("-")[1]]
within = [v for d in DS for k, v in O[d].items() if k.split("-")[0] == k.split("-")[1]]
N["occ_cross_min"], N["occ_cross_max"] = f2(min(cross)), f2(max(cross))
N["occ_within_min"], N["occ_within_max"] = f2(min(within)), f2(max(within))

# margin and classes
Mg = A["margin"]
N["unsw_mlp_q1"] = pct(Mg["unsw/mlp"][0]["flip"], 0); N["unsw_mlp_q4"] = pct(Mg["unsw/mlp"][3]["flip"], 0)
N["nsl_mlp_q4"] = pct(Mg["nslkdd/mlp"][3]["flip"], 0); N["unsw_rf_q4"] = pct(Mg["unsw/rf"][3]["flip"], 0)
C = A["classes"]
N["nsl_hgb_normal_flip"] = pct(C["nslkdd/hgb"]["normal"]["flip"], 0); N["nsl_hgb_r2l_flip"] = pct(C["nslkdd/hgb"]["r2l"]["flip"], 0)
N["nsl_lr_probe_flip"] = pct(C["nslkdd/lr"]["probe"]["flip"], 0); N["nsl_lr_normal_flip"] = pct(C["nslkdd/lr"]["normal"]["flip"], 0)
pr_att = [C[K(d, f)]["_all"]["flip_predatt"] for d in DS for f in FAMS]
allf = [C[K(d, f)]["_all"]["flip"] for d in DS for f in FAMS]
N["predatt_rng"] = rng(min(pr_att), max(pr_att), lambda x: pct(x, 0))
N["all_rng"] = rng(min(allf), max(allf), lambda x: pct(x, 0))

# STAX
X = A["stax"]
g8 = [X[K(d, f)]["8"]["jac5"] - X[K(d, f)]["1"]["jac5"] for d in DS for f in FAMS]
N["stax8_gain_min"], N["stax8_gain_max"] = f2(min(g8)), f2(max(g8))
N["mlp_K1_max"] = f2(max(X[K(d, "mlp")]["1"]["jac5"] for d in DS)); N["mlp_K8_min"] = f2(min(X[K(d, "mlp")]["8"]["jac5"] for d in DS))
assert all(X[K(d, f)]["8"]["jac5"] > T[K(d, f)]["seed"]["jac5"] for d in DS for f in ["rf", "hgb", "mlp"])
EA = A["ensacc"]
N["ens_acc_dmax_abs"] = f"{100*max(abs(EA[K(d, f)]['8']['acc'] - EA[K(d, f)]['1']['acc']) for d in DS for f in FAMS):.1f}"
fr = [(X[K(d, f)]["8"]["jac5"] - X[K(d, f)]["1"]["jac5"]) / (X[K(d, f)]["16"]["jac5"] - X[K(d, f)]["1"]["jac5"]) for d in DS for f in FAMS]
N["k8_frac_min"] = pct(min(fr), 0)
N["unsw_rf_K16_jac5"] = f2(X["unsw/rf"]["16"]["jac5"]); N["unsw_rf_K16_top1"] = f2(X["unsw/rf"]["16"]["top1"])
XG = A["xgen"]
gaps = [XG[K(d, f)]["0.0"]["5"]["jac5"] - XG[K(d, f)]["1.0"]["5"]["jac5"] for d in DS for f in ["lr", "rf", "hgb"]]
N["xgen_gap_rng"] = rng(min(gaps), max(gaps))
bf = [XG[K("nslkdd", f)]["1.0"]["bias_frac_K1"] for f in ["lr", "rf", "hgb"]]
sb = [XG[K(d, f)]["0.0"]["bias_frac_K1"] for d in DS for f in FAMS]
N["samemix_bias_rng"] = f"{min(sb):+.2f} to {max(sb):+.2f}"
N["bias_frac_rng"] = rng(min(bf), max(bf), lambda x: pct(x, 0))

# certificate
CE = A["cert"]
c8 = lambda f_, d, f: CE[K(d, f)]["8"][f_]
N["cert_minprec"] = pct(min(c8("prec", d, f) for d in DS for f in FAMS))
N["cert_maxprec"] = pct(max(c8("prec", d, f) for d in DS for f in FAMS))
N["unc_min"] = pct(min(c8("prec_unc", d, f) for d in DS for f in FAMS), 0)
N["unc_max"] = pct(max(c8("prec_unc", d, f) for d in DS for f in FAMS), 0)
N["rank_diff_max"] = f"{100*max(abs(CE[K(d, f)][k]['prec'] - CE[K(d, f)][k]['prec_rank']) for d in DS for f in FAMS for k in ('4', '8')):.1f} points"
N["gap_diff_max"] = f"{100*max(abs(CE[K(d, f)][k]['prec'] - CE[K(d, f)][k]['prec_gap']) for d in DS for f in FAMS for k in ('4', '8')):.1f} points"
fx = [c8("prec_fixed", d, f) for d in DS for f in FAMS]
N["fixed_rng"] = rng(min(fx), max(fx), lambda x: pct(x))
fg = [c8("prec", d, f) - c8("prec_fixed", d, f) for d in DS for f in FAMS]
N["fixed_gain_rng"] = f"{100*min(fg):.1f}–{100*max(fg):.1f}"
N["cov_lr_unsw"] = pct(c8("cov", "unsw", "lr"), 0); N["cov_mlp_nsl"] = pct(c8("cov", "nslkdd", "mlp"), 0)
CX = A["certx"]
cx = [CX[K("nslkdd", f)]["0.5"]["prec"] for f in FAMS]
N["certx_nsl_05_rng"] = rng(min(cx), max(cx), lambda x: pct(x, 0)) + \
    f" (from {pct(min(CX[K('nslkdd', f)]['0.0']['prec'] for f in FAMS), 0)}–{pct(max(CX[K('nslkdd', f)]['0.0']['prec'] for f in FAMS), 0)} on the original mix)"

# faithfulness
st = [F[d][f]["stale_ratio"] for d in DS for f in FAMS]
N["stale_ret_min"], N["stale_ret_max"] = pct(min(st)), pct(max(st))
N["rnd_ratio_max"] = pct(max(F[d][f]["random"] / F[d][f]["own"] for d in DS for f in FAMS), 0)
er = [F[d][f]["ens"] / F[d][f]["ens_single"] for d in DS for f in FAMS]
N["ens_ratio_min"], N["ens_ratio_max"] = f2(min(er)), f2(max(er))
sg = [F[d][f]["smooth"]["jac5_smooth"] - F[d][f]["smooth"]["jac5_raw"] for d in DS for f in ["rf", "hgb", "mlp"]]
N["smooth_gain_min"], N["smooth_gain_max"] = f"{min(sg):+.2f}", f"{max(sg):+.2f}"
rp = {(d, f): F[d][f]["repro_maxdiff"] for d in DS for f in FAMS}
N["repro_max_excl"] = f"{max(v for k, v in rp.items() if k != ('unsw', 'lr')):.0e}"
N["repro_lr_unsw"] = f2(rp[("unsw", "lr")])
sm = [(d, f) for d in DS for f in ["rf", "hgb", "lr"]]
N["loss_small_rng"] = f"{100*min(F[d][f]['loss_ci'][0] for d, f in sm):.0f}–{100*max(F[d][f]['loss_ci'][1] for d, f in sm):.0f}%"
N["loss_mlp_nsl"] = f"{100*F['nslkdd']['mlp']['loss_ci'][0]:.0f}–{100*F['nslkdd']['mlp']['loss_ci'][1]:.0f}%"
N["repro_max"] = f"{max(F[d][f]['repro_maxdiff'] for d in DS for f in FAMS):.1e}"
cp = {f: max(A["compl"][K(d, f)] for d in DS) for f in FAMS}
N["compl_mlp"] = f"{cp['mlp']:.3f}"; N["compl_tree"] = f"{max(cp['rf'], cp['hgb']):.0e}"; N["compl_lr"] = f"{cp['lr']:.0e}"
meta_t = {}
for p in glob.glob(f"{R}/members/*_retrain_0000[0-4].npz"):
    z = np.load(p); m = json.loads(str(z["meta"])); meta_t.setdefault(f"{m['ds']}/{m['fam']}", []).append(m["t_total"])
N["t_lr_nsl"] = f"{np.mean(meta_t['nslkdd/lr']):.1f}"; N["t_rf_unsw"] = f"{np.mean(meta_t['unsw/rf']):.0f}"

if __name__ == "__main__":
    for k, v in sorted(N.items()):
        print(k, "=", v)
