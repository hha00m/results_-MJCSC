// Assemble the manuscript .docx from paper/blocks.json (Elsevier single-column review layout).
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, WidthType,
  AlignmentType, BorderStyle, HeadingLevel, Footer, PageNumber, LineNumberRestartFormat,
  TabStopType, ShadingType, LevelFormat,
} = require("docx");

const B = JSON.parse(fs.readFileSync(path.join(__dirname, "blocks.json"), "utf8"));
const FONT = "Times New Roman";
const BODY = 24;          // 12 pt
const SMALL = 20;         // 10 pt (tables, captions)
const LINE = 360;         // 1.5 spacing
const PAGE_W = 11906, MARG = 1440, TEXT_W = PAGE_W - 2 * MARG;   // A4

function pngSize(p) {
  const b = fs.readFileSync(p);
  return [b.readUInt32BE(16), b.readUInt32BE(20)];
}

// inline markup: <i>..</i> <b>..</b> <sub>..</sub> <sup>..</sup>
function runs(text, base = {}) {
  const out = [];
  const re = /<(\/?)(i|b|sub|sup)>/g;
  let st = { i: false, b: false, sub: false, sup: false };
  let last = 0, m;
  const push = (s) => {
    if (!s) return;
    out.push(new TextRun({
      text: s, font: FONT, size: base.size || BODY, italics: st.i || base.italics,
      bold: st.b || base.bold, subScript: st.sub, superScript: st.sup, color: base.color,
    }));
  };
  while ((m = re.exec(text)) !== null) {
    push(text.slice(last, m.index));
    st[m[2]] = m[1] !== "/";
    last = re.lastIndex;
  }
  push(text.slice(last));
  return out;
}

function para(text, opt = {}) {
  return new Paragraph({
    alignment: opt.align || AlignmentType.JUSTIFIED,
    spacing: { line: opt.line || LINE, before: opt.before || 0, after: opt.after ?? 120 },
    indent: opt.indent,
    keepNext: opt.keepNext,
    keepLines: opt.keepLines,
    children: runs(text, opt.base || {}),
  });
}

const children = [];
const noB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const NOBORDERS = { top: noB, bottom: noB, left: noB, right: noB, insideHorizontal: noB, insideVertical: noB };

// ---------- front matter ----------
const M = B.meta;
children.push(para(M.title, { align: AlignmentType.CENTER, base: { bold: true, size: 32 }, after: 240, line: 300 }));
children.push(para(M.authors, { align: AlignmentType.CENTER, base: { size: BODY }, after: 60 }));
for (const a of M.affiliations) children.push(para(a, { align: AlignmentType.CENTER, base: { italics: true, size: SMALL }, after: 0, line: 276 }));
children.push(para(M.corresponding, { align: AlignmentType.CENTER, base: { size: SMALL }, before: 120, after: 240, line: 276 }));

for (const blk of B.blocks) {
  if (blk.t === "h1") {
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, keepNext: true,
      spacing: { before: 280, after: 120, line: LINE },
      children: [new TextRun({ text: blk.text, font: FONT, size: BODY, bold: true })] }));
  } else if (blk.t === "h2") {
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, keepNext: true,
      spacing: { before: 200, after: 100, line: LINE },
      children: [new TextRun({ text: blk.text, font: FONT, size: BODY, bold: true, italics: true })] }));
  } else if (blk.t === "label") {
    children.push(para(blk.text, { base: { bold: true }, after: 60, keepNext: true }));
  } else if (blk.t === "p") {
    children.push(para(blk.text, { indent: blk.noindent ? undefined : { firstLine: 0 } }));
  } else if (blk.t === "items") {
    for (const it of blk.items) children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED,
      spacing: { line: LINE, after: 60 }, indent: { left: 567, hanging: 567 },
      tabStops: [{ type: TabStopType.LEFT, position: 567 }], children: runs(it) }));
  } else if (blk.t === "bullets") {
    for (const it of blk.items) children.push(new Paragraph({
      numbering: { reference: "bul", level: 0 }, spacing: { line: LINE, after: 40 },
      children: runs(it) }));
  } else if (blk.t === "eq") {
    const [w, h] = pngSize(blk.img);
    let wi = (w / 600) * 1.15, hi = (h / 600) * 1.15;
    const maxW = 5.6;
    if (wi > maxW) { hi *= maxW / wi; wi = maxW; }
    const eqW = TEXT_W - 900;
    children.push(new Table({
      width: { size: TEXT_W, type: WidthType.DXA }, columnWidths: [eqW, 900], borders: NOBORDERS,
      rows: [new TableRow({ cantSplit: true, children: [
        new TableCell({ width: { size: eqW, type: WidthType.DXA }, borders: NOBORDERS, verticalAlign: "center",
          children: [new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 60 },
            children: [new ImageRun({ type: "png", data: fs.readFileSync(blk.img),
              transformation: { width: Math.round(wi * 96), height: Math.round(hi * 96) } })] })] }),
        new TableCell({ width: { size: 900, type: WidthType.DXA }, borders: NOBORDERS, verticalAlign: "center",
          children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: runs(`(${blk.num})`) })] }),
      ] })],
    }));
  } else if (blk.t === "fig") {
    const [w, h] = pngSize(blk.img);
    const wi = blk.width || 6.2, hi = wi * h / w;
    children.push(new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 60 },
      children: [new ImageRun({ type: "png", data: fs.readFileSync(blk.img),
        transformation: { width: Math.round(wi * 96), height: Math.round(hi * 96) } })] }));
    children.push(para(`<b>Fig. ${blk.num}.</b> ${blk.caption}`, { base: { size: SMALL }, line: 276, after: 200, align: AlignmentType.JUSTIFIED }));
  } else if (blk.t === "table") {
    children.push(para(`<b>Table ${blk.num}</b>`, { base: { size: SMALL }, line: 276, after: 0, keepNext: true, before: 120 }));
    children.push(para(blk.caption, { base: { size: SMALL }, line: 276, after: 80, keepNext: true }));
    const ncol = blk.header.length;
    const widths = blk.widths ? blk.widths.map(x => Math.round(x * TEXT_W / blk.widths.reduce((a, b) => a + b, 0)))
                              : Array(ncol).fill(Math.floor(TEXT_W / ncol));
    const tw = widths.reduce((a, b) => a + b, 0);
    const rule = (sz) => ({ style: BorderStyle.SINGLE, size: sz, color: "000000" });
    const mkRow = (cells, i, isHead, isLast, groupTop) => new TableRow({ cantSplit: true, tableHeader: isHead,
      children: cells.map((c, j) => new TableCell({
        width: { size: widths[j], type: WidthType.DXA },
        margins: { top: 30, bottom: 30, left: 70, right: 70 },
        borders: { left: noB, right: noB,
          top: isHead ? rule(8) : (groupTop ? rule(2) : noB),
          bottom: isHead ? rule(4) : (isLast ? rule(8) : noB) },
        children: [new Paragraph({ alignment: j === 0 ? AlignmentType.LEFT : AlignmentType.CENTER,
          spacing: { line: 240, before: 0, after: 0 }, keepNext: !isLast, keepLines: true,
          children: runs(String(c), { size: SMALL, bold: isHead }) })],
      })) });
    const rows = [mkRow(blk.header, 0, true, false)];
    blk.rows.forEach((r, i) => rows.push(mkRow(r, i + 1, false, i === blk.rows.length - 1,
      (blk.groupStarts || []).includes(i) && i > 0)));
    children.push(new Table({ width: { size: tw, type: WidthType.DXA }, columnWidths: widths, rows }));
    if (blk.note) children.push(para(blk.note, { base: { size: 18 }, line: 240, before: 60, after: 200 }));
    else children.push(para("", { after: 120 }));
  } else if (blk.t === "alg") {
    const cellB = { top: rule2(8), bottom: rule2(8), left: noB, right: noB };
    function rule2(sz) { return { style: BorderStyle.SINGLE, size: sz, color: "000000" }; }
    const paras = [new Paragraph({ spacing: { after: 60 }, border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "000000", space: 2 } },
      children: runs(`<b>Algorithm ${blk.num}</b> ${blk.title}`, { size: SMALL }) })];
    for (const L of blk.lines) {
      paras.push(new Paragraph({ spacing: { line: 250, after: 0 }, indent: { left: 360 + 360 * (L.indent || 0), hanging: L.n ? 360 : 0 },
        children: [new TextRun({ text: L.n ? `${L.n}:\t` : "", font: FONT, size: SMALL }), ...runs(L.text, { size: SMALL })],
        tabStops: [{ type: TabStopType.LEFT, position: 360 }] }));
    }
    children.push(new Table({ width: { size: TEXT_W, type: WidthType.DXA }, columnWidths: [TEXT_W],
      rows: [new TableRow({ cantSplit: true, children: [new TableCell({ width: { size: TEXT_W, type: WidthType.DXA }, borders: cellB,
        margins: { top: 60, bottom: 80, left: 60, right: 60 }, children: paras })] })] }));
    children.push(para("", { after: 120 }));
  } else if (blk.t === "refs") {
    blk.items.forEach((r, i) => children.push(new Paragraph({
      spacing: { line: 276, after: 60 }, indent: { left: 567, hanging: 567 },
      tabStops: [{ type: TabStopType.LEFT, position: 567 }],
      children: [new TextRun({ text: `[${i + 1}]\t`, font: FONT, size: SMALL }), ...runs(r, { size: SMALL })] })));
  } else {
    throw new Error("unknown block " + blk.t);
  }
}

const doc = new Document({
  creator: M.authorsPlain, title: M.titlePlain,
  styles: {
    default: { document: { run: { font: FONT, size: BODY } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: BODY, bold: true }, paragraph: { outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: BODY, bold: true, italics: true }, paragraph: { outlineLevel: 1 } },
    ],
  },
  numbering: { config: [{ reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•",
    alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 360 } } } }] }] },
  sections: [{
    properties: {
      page: { size: { width: PAGE_W, height: 16838 }, margin: { top: MARG, bottom: MARG, left: MARG, right: MARG } },
      lineNumbers: { countBy: 1, restart: LineNumberRestartFormat.CONTINUOUS, distance: 300 },
    },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: SMALL })] })] }) },
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(B.out, buf);
  console.log("wrote", B.out);
});
