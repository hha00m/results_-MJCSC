"""Assemble the revised manuscript (after the internal referee panel).
Hard-errors on unknown placeholders or citation keys."""
import json, re, string, subprocess, sys
sys.path.insert(0, "/home/claude/xstab"); sys.path.insert(0, "/home/claude/xstab/paper")
from paper_numbers2 import N, A, F
from refs import REFS
import text_front as TF
import text_results2 as TR

REFS = dict(REFS)
REFS["mchugh2000"] = "J. McHugh, Testing intrusion detection systems: a critique of the 1998 and 1999 DARPA intrusion detection system evaluations as performed by Lincoln Laboratory, ACM Trans. Inf. Syst. Secur. 3 (4) (2000) 262–294. https://doi.org/10.1145/382912.382923."
OUT = "/home/claude/xstab/paper/Algabri_XAI_IDS_stability_manuscript.docx"
EQ = "/home/claude/xstab/paper/eq"; FIG = "/home/claude/xstab/figures"
FAMS = ["lr", "rf", "hgb", "mlp"]; LAB = {"lr": "LR", "rf": "RF", "hgb": "HGB", "mlp": "MLP"}
DSL = {"nslkdd": "NSL-KDD", "unsw": "UNSW-NB15"}
DSA = {"nslkdd": "NSL", "unsw": "UNSW"}
cite_order = []


def fill(s):
    for _, k, _, _ in string.Formatter().parse(s):
        if k and k not in N:
            raise KeyError(f"unknown placeholder {{{k}}} in: {s[:90]}")
    s = s.format(**N)

    def rep(m):
        ks = [k.strip().lstrip("@") for k in m.group(1).split(";")]
        nums = []
        for k in ks:
            if k not in REFS:
                raise KeyError("unknown citation " + k)
            if k not in cite_order:
                cite_order.append(k)
            nums.append(cite_order.index(k) + 1)
        nums = sorted(set(nums)); parts, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            parts.append(f"{nums[i]}–{nums[j]}" if j - i >= 2 else ",".join(map(str, nums[i:j + 1])))
            i = j + 1
        return "[" + ",".join(parts) + "]"
    return re.sub(r"\[(@[^\]]+)\]", rep, s)


B = []
P = lambda t: B.append({"t": "p", "text": fill(t)})
H1 = lambda t: B.append({"t": "h1", "text": t})
H2 = lambda t: B.append({"t": "h2", "text": t})
eqn = [0]


def EQN(name):
    eqn[0] += 1
    assert name == f"eq{eqn[0]}", (name, eqn[0])
    B.append({"t": "eq", "img": f"{EQ}/{name}.png", "num": eqn[0]})


def ci(v, c):
    return f"{v:.2f} [{c[0]:.2f}, {c[1]:.2f}]"


B.append({"t": "label", "text": "Highlights"})
B.append({"t": "bullets", "items": TR.HIGHLIGHTS})
B.append({"t": "label", "text": "Abstract"})
P(TR.ABSTRACT)
B.append({"t": "p", "text": "<b>Keywords:</b> Intrusion detection; Explainable AI; SHAP; Explanation stability; Rashomon effect; Ensemble attribution"})

H1("1. Introduction")
for t in TF.INTRO:
    P(t)
P("The contributions of this paper are as follows:")
B.append({"t": "items", "items": [fill(f"({i+1})\t" + c) for i, c in enumerate(TF.CONTRIB)]})
P("Section 2 reviews related work. Section 3 defines the measurement framework and Section 4 presents STAX. Section 5 describes the experimental setup, Section 6 reports results, and Section 7 discusses implications and limitations before Section 8 concludes.")

H1("2. Related work")
H2("2.1. Explanations for intrusion detection")
for t in TF.RW["xai_ids"]: P(t)
H2("2.2. Robustness and disagreement of explanations")
for t in TF.RW["robust"]: P(t)
H2("2.3. Multiplicity of good models")
for t in TF.RW["rashomon"]: P(t)

H1("3. Measuring attribution drift")
P("Fig. 1(a) outlines the measurement framework; this section defines its parts.")
B.append({"t": "fig", "img": f"{FIG}/fig1_framework.png", "num": 1, "width": 6.3,
          "caption": "Overview. (a) Detectors are trained under four drift sources, explained with explainers that are deterministic given the model, and compared with local and global stability metrics. (b) STAX deploys a <i>K</i>-member ensemble, explains it exactly as the mean of member attributions, and certifies top-<i>k</i> features with a bootstrap over members."})
H2("3.1. Setting and drift sources")
P(TF.METHOD["setting"][0]); EQN("eq1")
P(TF.METHOD["setting"][1]); EQN("eq2")
H2("3.2. Stability metrics")
P(TF.METHOD["metrics"][0]); EQN("eq3"); EQN("eq4")
P(TF.METHOD["metrics"][1]); EQN("eq5"); EQN("eq6")

H1("4. STAX: stability-aware explanation aggregation")
H2("4.1. Exact attribution of a retrained ensemble")
P(TF.METHOD["stax"][0]); EQN("eq7")
H2("4.2. Variance and bias of ensemble explanations")
P(TF.METHOD["stax"][1]); EQN("eq8"); EQN("eq9")
P(TF.METHOD["stax"][2]); P(TF.METHOD["stax"][3])
H2("4.3. Rank certificate")
P(TF.METHOD["stax"][4]); EQN("eq10")
B.append({"t": "alg", "num": 1, "title": "STAX: stability-aware explanation aggregation and certification",
          "lines": [{"n": n, "indent": ind, "text": t} for n, ind, t in TF.ALG]})
P(TF.METHOD["stax"][5])

H1("5. Experimental setup")
H2("5.1. Data")
P(TR.SETUP["data"][0])
from data import load
rows = []
for ds in ["nslkdd", "unsw"]:
    d = load(ds); n = len(d["ytr"])
    rows.append([DSL[ds], f"{n:,}", f"{n - n//10:,}", f"{len(d['yte']):,}", f"{len(d['gnames'])} ({d['Xtr'].shape[1]})",
                 str(len(set(d["ftr"]) - {"normal"})), f"{d['ytr'].mean():.3f} / {d['yte'].mean():.3f}"])
B.append({"t": "table", "num": 1, "caption": "Data sets. <i>G</i> is the number of analyst-facing features after grouping one-hot columns (encoded width in parentheses). The training pool excludes a 10% in-distribution holdout.",
          "header": ["Data set", "Train records", "Training pool", "Test records", "<i>G</i> (encoded)", "Attack families", "Attack fraction train / test"],
          "rows": rows, "widths": [1.3, 1.1, 1.1, 1.0, 1.1, 0.9, 1.5]})
P(TR.SETUP["data"][1])
H2("5.2. Detectors and explainers")
P(TR.SETUP["models"][0])
B.append({"t": "table", "num": 2, "caption": "Detectors, hyperparameters and explainers (scikit-learn 1.9.1, shap 0.52.0). 'Randomness' lists what the seed controls.",
          "header": ["Family", "Hyperparameters", "Randomness", "Explainer (output space)"],
          "rows": [["LR", "L2, <i>C</i> = 1, lbfgs, tolerance 10<sup>−10</sup>", "none (convex)", "exact linear SHAP, common reference (log-odds)"],
                   ["RF", "100 trees, max depth 20, min leaf 2, √<i>d</i> features", "bootstrap, feature subsets", "path-dependent TreeSHAP (probability)"],
                   ["HGB", "200 iterations, learning rate 0.1, early stopping (10% validation)", "validation split only", "path-dependent TreeSHAP (log-odds)"],
                   ["MLP", "64–32 ReLU, Adam, lr 10<sup>−3</sup>, batch 256, α = 10<sup>−4</sup>, early stopping", "initialisation, batches, validation split", "Integrated Gradients, 64 steps, common reference (logit)"]],
          "widths": [0.6, 2.5, 1.5, 2.1]})
P(TR.SETUP["models"][1])
H2("5.3. Protocol")
for t in TR.SETUP["protocol"][:3]: P(t)
EQN("eq11")
P("Here <i>r</i> is a feature ranking, <b>x</b><sup>(<i>r,k</i>)</sup> is <b>x</b> with its first <i>k</i> ranked features replaced, <i>t</i> is the decision threshold in the output space of <i>f</i>, and <i>k</i><sub>max</sub> = 5. Larger values mean that the ranking identifies features the model actually relies on.")
P(TR.SETUP["protocol"][3])

H1("6. Results")
H2("6.1. Accuracy is stable; explanations are not")
P(TR.RESULTS["main"][0])
T = A["tab"]; rows, grp = [], []
for ds in ["nslkdd", "unsw"]:
    grp.append(len(rows))
    for f in FAMS:
        t = T[f"{ds}/{f}"]; a = A["acc"][f"{ds}/{f}"]
        rows.append([f"{DSA[ds]} – {LAB[f]}", f"{100*a['retrain']:.1f} ± {100*a['retrain_sd']:.1f}",
                     f"{t['seed']['jac5']:.2f}", ci(t["retrain"]["jac5"], t["retrain"]["ci"]["jac5"]), f"{t['seed']['top1']:.2f}",
                     ci(t["retrain"]["top1"], t["retrain"]["ci"]["top1"]), f"{t['retrain']['sign']:.2f}", f"{t['retrain']['rho']:.2f}", f"{t['retrain']['g_tau']:.2f}"])
B.append({"t": "table", "num": 3, "caption": "Accuracy and explanation stability within each family, averaged over all member pairs (95% member-level bootstrap intervals in brackets). Acc: test accuracy of retrain members (mean ± s.d., %); <i>J</i><sub>5</sub>, <i>A</i><sub>1</sub>: local top-5 Jaccard and top-1 agreement under seed (sd) and retrain (rt) drift; <i>S</i><sub>5</sub>: top-5 sign agreement; ρ: per-flow Spearman correlation; τ: global Kendall τ (retrain). Higher is more stable. NSL = NSL-KDD, UNSW = UNSW-NB15 (also in Tables 5–7).",
          "header": ["Set – family", "Acc (%)", "<i>J</i><sub>5</sub> sd", "<i>J</i><sub>5</sub> rt", "<i>A</i><sub>1</sub> sd", "<i>A</i><sub>1</sub> rt", "<i>S</i><sub>5</sub> rt", "ρ rt", "τ rt"],
          "rows": rows, "groupStarts": grp, "widths": [1.3, 0.95, 0.55, 1.4, 0.55, 1.4, 0.55, 0.55, 0.55],
          "note": "LR has no seed-dependent randomness; its seed members are identical by construction and serve as a control."})
for t in TR.RESULTS["main"][1:]: P(t)
H2("6.2. Attack-mix shift and input shift")
P(TR.RESULTS["shift"][0])
B.append({"t": "fig", "img": f"{FIG}/fig2_shift.png", "num": 2, "width": 6.5,
          "caption": "Local top-5 agreement between members trained on a shifted attack mix and ten fixed original members (solid, 95% member-level bootstrap intervals), plotted against the Jensen–Shannon divergence of the mix. The JS = 0 point compares five further original members with the same references. Dotted: agreement among members trained on the same mix. Star: no-duplication control."})
for t in TR.RESULTS["shift"][1:]: P(t)
H2("6.3. Different families, different explanations")
P(TR.RESULTS["rashomon"][0])
B.append({"t": "fig", "img": f"{FIG}/fig3_rashomon.png", "num": 3, "width": 5.4,
          "caption": "Mean local top-5 Jaccard between families trained on the same samples. Lower triangle: each family's own explainer (16 member pairs). Upper triangle: all families explained by the same occlusion explainer in log-odds space (8 member pairs). Diagonal (bold): two retrained members of the same family, native explainers."})
P(TR.RESULTS["rashomon"][1])
tf = A["top_features"]
B.append({"t": "table", "num": 4, "caption": "Five most important features (global ranking of the mean attribution of the 32 retrain members). Features in bold appear in the top five of every family on that data set; on UNSW-NB15 no feature does, because LR ranks neither sttl nor service in its top five.",
          "header": ["Family", "NSL-KDD", "UNSW-NB15"],
          "rows": [[LAB[f]] + [", ".join(("<b>" + x + "</b>") if all(x in tf[ds][g][:5] for g in FAMS) else x for x in tf[ds][f][:5])
                               for ds in ["nslkdd", "unsw"]] for f in FAMS],
          "widths": [0.7, 3.2, 3.2]})
H2("6.4. Where instability concentrates")
P(TR.RESULTS["where"][0])
B.append({"t": "fig", "img": f"{FIG}/fig4_margin.png", "num": 4, "width": 6.0,
          "caption": "Fraction of retrain pairs whose leading feature differs, by quartile of the ensemble-mean prediction margin |<i>p̄</i> − 0.5| (125 flows per quartile; 95% bootstrap intervals over flows). Q1 holds the most uncertain flows. Intervals resample flows and do not account for member clustering."})
P(TR.RESULTS["where"][1])
H2("6.5. STAX: aggregation within and across distributions")
P(TR.RESULTS["stax"][0])
X = A["stax"]; EA = A["ensacc"]; rows, grp = [], []
for ds in ["nslkdd", "unsw"]:
    grp.append(len(rows))
    for f in FAMS:
        x = X[f"{ds}/{f}"]; xg = A["xgen"][f"{ds}/{f}"]
        rows.append([f"{DSA[ds]} – {LAB[f]}"] + [f"{x[k]['jac5']:.2f}" for k in ["1", "4", "8", "16"]] +
                    [f"{x[k]['top1']:.2f}" for k in ["1", "8"]] + [f"{xg['1.0']['5']['jac5']:.2f}",
                    f"{100*EA[f'{ds}/{f}']['1']['acc']:.1f}", f"{100*EA[f'{ds}/{f}']['8']['acc']:.1f}"])
B.append({"t": "table", "num": 5, "caption": "STAX: agreement between two disjoint <i>K</i>-member ensembles from the same distribution (<i>K</i> = 1: all retrain pairs; otherwise 200 random partitions), agreement at <i>K</i> = 5 between an original and a λ = 1 ensemble (Shift), and test accuracy (%) of a single member and of the deployed 8-member ensemble.",
          "header": ["Set – family", "<i>J</i><sub>5</sub> K=1", "<i>J</i><sub>5</sub> K=4", "<i>J</i><sub>5</sub> K=8", "<i>J</i><sub>5</sub> K=16", "<i>A</i><sub>1</sub> K=1", "<i>A</i><sub>1</sub> K=8", "Shift <i>J</i><sub>5</sub> K=5", "Acc K=1", "Acc K=8"],
          "rows": rows, "groupStarts": grp, "widths": [1.2, 0.7, 0.7, 0.7, 0.75, 0.7, 0.7, 0.85, 0.7, 0.7]})
B.append({"t": "fig", "img": f"{FIG}/fig5_stax.png", "num": 5, "width": 6.5,
          "caption": "Left pair: local top-5 Jaccard between two disjoint STAX ensembles from the same distribution versus ensemble size <i>K</i> (error bars: s.d. over 200 partitions). Right pair: agreement between ensembles of original members (solid) and between an original and a λ = 1 ensemble (dotted); the gap that remains as <i>K</i> grows is the bias term of Eq. (8)."})
for t in TR.RESULTS["stax"][1:]: P(t)
H2("6.6. STAX: certification")
P(TR.RESULTS["cert"][0])
CE = A["cert"]; CX = A["certx"]; rows, grp = [], []
for ds in ["nslkdd", "unsw"]:
    grp.append(len(rows))
    for f in FAMS:
        c = CE[f"{ds}/{f}"]["8"]; cx = CX[f"{ds}/{f}"]
        rows.append([f"{DSA[ds]} – {LAB[f]}", f"{100*c['prec']:.1f}", f"{100*c['prec_rank']:.1f}", f"{100*c['prec_gap']:.1f}",
                     f"{100*c['prec_fixed']:.1f}", f"{100*c['prec_unc']:.1f}", f"{100*c['cov']:.0f}",
                     f"{100*cx['0.0']['prec']:.1f}", f"{100*cx['0.5']['prec']:.1f}"])
B.append({"t": "table", "num": 6, "caption": "Certificate evaluation (δ = 0.1, <i>k</i> = 5, <i>B</i> = 200). Columns 2–7: <i>K</i> = 8, 50 partitions; precision (%) = share of certified features in the top-5 of an independent same-distribution ensemble. Rank, Gap and Fixed are baselines certifying the same number of features (top-ranked per flow; gap threshold; same count in every flow). Uncert.: same check for non-certified top-5 features. Cov.: % of top-5 slots certified. Last two columns: certificate from 5 original members checked against 5 further original members (λ = 0) or 5 members trained at λ = 0.5.",
          "header": ["Set – family", "STAX", "Rank", "Gap", "Fixed", "Uncert.", "Cov.", "λ = 0", "λ = 0.5"],
          "rows": rows, "groupStarts": grp, "widths": [1.2, 0.7, 0.7, 0.7, 0.7, 0.75, 0.6, 0.7, 0.75]})
P(TR.RESULTS["cert"][1])
H2("6.7. Faithfulness: what drift costs")
P(TR.RESULTS["faith"][0])
rows, grp = [], []
for ds in ["nslkdd", "unsw"]:
    grp.append(len(rows))
    for f in FAMS:
        r = F[ds][f]
        rows.append([f"{DSA[ds]} – {LAB[f]}", f"{r['own']:.3f}", f"{r['stale']:.3f}", f"{r['random']:.3f}", f"{100*r['stale_ratio']:.1f}",
                     f"{100*r['loss_ci'][0]:.1f}–{100*r['loss_ci'][1]:.1f}", f"{r['ens']:.3f}", f"{r['ens_single']:.3f}",
                     f"{r['smooth']['jac5_raw']:.2f} / {r['smooth']['jac5_smooth']:.2f}"])
B.append({"t": "table", "num": 7, "caption": "Deletion faithfulness (AOPC, Eq. (11), in each model's output space, so values are comparable within a row only). Own / Stale / Random: ranking from the model itself, from a different retrained member (56 ordered pairs), or random. Loss CI: 95% bootstrap interval (over flows) of the relative AOPC loss of stale rankings, in %. Ens. / Single: 8-member ensemble explained by its own ranking or by one member's. Last column: retrain <i>J</i><sub>5</sub> without / with input smoothing.",
          "header": ["Set – family", "Own", "Stale", "Random", "Stale/Own (%)", "Loss CI (%)", "Ens.", "Single", "<i>J</i><sub>5</sub> raw / smooth"],
          "rows": rows, "groupStarts": grp, "widths": [1.2, 0.7, 0.7, 0.85, 0.85, 1.0, 0.7, 0.7, 1.2]})
P(TR.RESULTS["faith"][1])

H1("7. Discussion")
for t in TR.DISCUSSION: P(t)
H1("8. Conclusion")
for t in TR.CONCLUSION: P(t)
for k in ["credit", "competing", "funding", "data", "genai"]:
    P(TR.DECL[k])
H1("References")
unused = [k for k in REFS if k not in cite_order]
if unused:
    print("WARNING uncited refs:", unused)
B.append({"t": "refs", "items": [REFS[k] for k in cite_order]})
meta = {
    "title": "Are Intrusion Detection Explanations Stable? Measuring Attribution Drift across Retraining, Seeds and Data Shift",
    "titlePlain": "Are Intrusion Detection Explanations Stable? Measuring Attribution Drift across Retraining, Seeds and Data Shift",
    "authors": "Hayder Kareem Algabri<sup>a,*</sup>", "authorsPlain": "Hayder Kareem Algabri",
    "affiliations": ["<sup>a</sup> Department of Engineering Cybersecurity Techniques, College of Engineering Techniques, University of Hilla, Babylon, Iraq"],
    "corresponding": "* Corresponding author. E-mail: hayder_kareem_algabri@hilla-unc.edu.iq (H.K. Algabri). ORCID: 0000-0002-5359-9147",
}
for b in B:
    for v in ([b.get("text", "")] + b.get("items", [])):
        if re.search(r"\{[a-zA-Z_0-9]+\}", v):
            raise SystemExit("unfilled placeholder in: " + v[:100])
json.dump({"meta": meta, "blocks": B, "out": OUT}, open("/home/claude/xstab/paper/blocks.json", "w"), ensure_ascii=False)
abstract_words = len(re.sub(r"<[^>]+>", "", fill(TR.ABSTRACT)).split())
print("refs cited:", len(cite_order), "equations:", eqn[0], "abstract words:", abstract_words,
      "highlight chars:", [len(h) for h in TR.HIGHLIGHTS])
r = subprocess.run(["node", "/home/claude/xstab/paper/build_docx.js"], capture_output=True, text=True)
print(r.stdout, r.stderr[-2000:])
