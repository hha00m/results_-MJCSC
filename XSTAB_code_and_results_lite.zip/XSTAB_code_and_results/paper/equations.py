"""Render display equations to 600-dpi cropped PNGs (pdflatex + standalone + mathptmx)."""
import os, subprocess

OUT = "/home/claude/xstab/paper/eq"
os.makedirs(OUT, exist_ok=True)

EQ = {
 "eq1": r"\phi_g(f,\mathbf{x}) \;=\; \sum_{c\in\mathcal{C}_g} \phi_c(f,\mathbf{x}), \qquad g=1,\dots,G",
 "eq2": r"\pi_\lambda \;=\; (1-\lambda)\,\pi_0 + \lambda\,\mathbf{u}, \qquad \lambda\in[0,1]",
 "eq3": r"J_k(\mathbf{a},\mathbf{b}) \;=\; \frac{|T_k(\mathbf{a})\cap T_k(\mathbf{b})|}{|T_k(\mathbf{a})\cup T_k(\mathbf{b})|},\qquad A_1(\mathbf{a},\mathbf{b}) \;=\; \mathbf{1}\!\left[T_1(\mathbf{a})=T_1(\mathbf{b})\right]",
 "eq4": r"S_k(\mathbf{a},\mathbf{b}) \;=\; \frac{1}{k}\sum_{g\in T_k(\mathbf{a})} \mathbf{1}\!\left[\operatorname{sign}(a_g)=\operatorname{sign}(b_g)\right]",
 "eq5": r"I_g(f) \;=\; \frac{1}{n}\sum_{i=1}^{n}\left|\phi_g(f,\mathbf{x}_i)\right|,\qquad \tau(f,f') \;=\; \text{Kendall-}\tau\big(\mathbf{I}(f),\mathbf{I}(f')\big),\qquad J_k^{\mathrm{glob}}(f,f') \;=\; J_k\big(\mathbf{I}(f),\mathbf{I}(f')\big)",
 "eq6": r"\bar{J}_k(\mathcal{S}) \;=\; \mathbb{E}_{(D,\xi),(D',\xi')\sim\mathcal{S}}\;\frac{1}{n}\sum_{i=1}^{n} J_k\big(\phi(f_{D,\xi},\mathbf{x}_i),\,\phi(f_{D',\xi'},\mathbf{x}_i)\big)",
 "eq7": r"F_K(\mathbf{x}) \;=\; \frac{1}{K}\sum_{m=1}^{K} f_m(\mathbf{x}),\qquad \Phi_K(\mathbf{x}) \;=\; \frac{1}{K}\sum_{m=1}^{K}\phi(f_m,\mathbf{x}) \;=\; \phi(F_K,\mathbf{x})",
 "eq8": r"\mathbb{E}\,\big\|\Phi_K^{A}(\mathbf{x})-\Phi_K^{B}(\mathbf{x})\big\|_2^2 \;=\; \underbrace{\big\|\boldsymbol{\mu}_A(\mathbf{x})-\boldsymbol{\mu}_B(\mathbf{x})\big\|_2^2}_{\text{generation bias}} \;+\; \frac{\operatorname{tr}\Sigma_A(\mathbf{x})+\operatorname{tr}\Sigma_B(\mathbf{x})}{K}",
 "eq9": r"\Pr\!\big[s_i\Phi_{K,i}(\mathbf{x}) \le s_j\Phi_{K,j}(\mathbf{x})\big] \;\le\; \frac{v_{ij}}{v_{ij}+K\,\Delta_{ij}^{2}}",
 "eq10": r"p_g(\mathbf{x}) \;=\; \frac{1}{B}\sum_{b=1}^{B}\mathbf{1}\!\left[g\in T_k\big(\Phi^{(b)}(\mathbf{x})\big)\right],\qquad \mathcal{C}_\delta(\mathbf{x}) \;=\; \big\{g\in T_k(\Phi_K(\mathbf{x})) : p_g(\mathbf{x})\ge 1-\delta\big\}",
 "eq11": r"\mathrm{AOPC}(f,r) \;=\; \frac{1}{k_{\max}}\sum_{k=1}^{k_{\max}} \mathbb{E}_{\mathbf{x}}\Big[\big(f(\mathbf{x})-f(\mathbf{x}^{(r,k)})\big)\,\operatorname{sign}\big(f(\mathbf{x})-t\big)\Big]",
}

TEX = r"""\documentclass[border=1pt,varwidth=16cm]{standalone}
\usepackage{amsmath,amssymb,bm}
\usepackage{mathptmx}
\begin{document}
$\displaystyle %s$
\end{document}
"""

for k, v in EQ.items():
    tex = f"{OUT}/{k}.tex"
    open(tex, "w").write(TEX % v)
    r = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-output-directory", OUT, tex],
                       capture_output=True, text=True)
    if r.returncode:
        print(r.stdout[-1500:]); raise SystemExit(k)
    subprocess.run(["pdftoppm", "-png", "-r", "600", "-singlefile", f"{OUT}/{k}.pdf", f"{OUT}/{k}"], check=True)
    print(k, "ok")
for f in os.listdir(OUT):
    if not f.endswith(".png"):
        os.remove(f"{OUT}/{f}")
