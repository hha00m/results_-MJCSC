"""Independent re-derivation of headline numbers directly from the per-member .npz
files, with code written separately from metrics.py / analyze2.py. Compares with
the values used in the manuscript (paper_numbers2.N)."""
import glob, json, sys, itertools
import numpy as np
sys.path.insert(0, "/home/claude/xstab/paper")
from paper_numbers2 import N

R = "/home/claude/xstab/results/members"


def members(ds, fam, regime):
    out = []
    for p in sorted(glob.glob(f"{R}/{ds}_{fam}_{regime}_*.npz")):
        z = np.load(p); out.append((json.loads(str(z["meta"])), z["phi_te"].astype(float), z["pred_te"]))
    return out


def top_sets(phi, k):
    # independent implementation: explicit sort per row
    return [frozenset(np.argsort(np.abs(r))[::-1][:k].tolist()) for r in phi]


def jac(a, b, k=5):
    sa, sb = top_sets(a, k), top_sets(b, k)
    return np.mean([len(x & y) / len(x | y) for x, y in zip(sa, sb)])


checks = []


def check(name, mine, quoted, tol):
    ok = abs(mine - quoted) <= tol
    checks.append(ok)
    print(f"{'OK ' if ok else 'BAD'} {name}: recomputed {mine:.4f} vs manuscript {quoted:.4f}")


DS, FAMS = ["nslkdd", "unsw"], ["lr", "rf", "hgb", "mlp"]
ret_j = {}
for ds in DS:
    for fam in FAMS:
        ret = members(ds, fam, "retrain")
        ret_j[(ds, fam)] = np.mean([jac(ret[i][1], ret[j][1]) for i, j in itertools.combinations(range(len(ret)), 2)])
check("min retrain J5", min(ret_j.values()), float(N["intro_ret_jac_min"]), 0.006)
check("max retrain J5", max(ret_j.values()), float(N["intro_ret_jac_max"]), 0.006)

seed = members("nslkdd", "mlp", "seed")
flip = np.mean([np.mean(np.argmax(np.abs(seed[i][1]), 1) != np.argmax(np.abs(seed[j][1]), 1))
                for i, j in itertools.combinations(range(10), 2)])
check("NSL MLP seed top-1 flip", flip, float(N["intro_mlp_flip"].rstrip("%")) / 100, 0.006)

pa = []
for ds in DS:
    for fam in FAMS:
        ret = members(ds, fam, "retrain")
        pa.append(np.mean([np.mean(ret[i][2] == ret[j][2]) for i, j in itertools.combinations(range(len(ret)), 2)]))
check("min verdict agreement", min(pa), float(N["pa_min"].rstrip("%")) / 100, 0.0006)

# STAX K=8 gain (different random partitions -> tolerance)
rng = np.random.default_rng(123); gains = []
for ds in DS:
    for fam in FAMS:
        ret = members(ds, fam, "retrain"); phis = np.stack([m[1] for m in ret])
        v = []
        for _ in range(60):
            p = rng.permutation(32); v.append(jac(phis[p[:8]].mean(0), phis[p[8:16]].mean(0)))
        gains.append(np.mean(v) - ret_j[(ds, fam)])
check("min STAX K=8 gain", min(gains), float(N["stax8_gain_min"]), 0.02)
check("max STAX K=8 gain", max(gains), float(N["stax8_gain_max"]), 0.02)

# shift lambda=1 vs refs (retrain 0..9)
for fam in ["lr", "rf", "hgb"]:
    ret = members("nslkdd", fam, "retrain"); sh = [m for m in members("nslkdd", fam, "shift") if m[0]["lam"] == 1.0]
    v = np.mean([jac(a[1], b[1]) for a in sh for b in ret[:10]])
    check(f"NSL {fam} lambda=1 J5", v, float(N[f"nslkdd_{fam}_shift1_jac5"]), 0.006)

# accuracy SD
sds = [np.std([m[0]["acc"] for m in members(ds, fam, "retrain")]) for ds in DS for fam in FAMS]
check("max retrain accuracy s.d. (pp)", 100 * max(sds), float(N["intro_max_acc_sd"]), 0.051)

# faithfulness ratio range (from per-family json, recomputed min/max)
fr = [json.load(open(f"/home/claude/xstab/results/faith_{ds}_{f}.json"))["stale_ratio"] for ds in DS for f in FAMS]
check("min stale/own", min(fr), float(N["stale_ret_min"].rstrip("%")) / 100, 0.0006)
print(f"\n{sum(checks)}/{len(checks)} checks passed")
