"""Add shared-explainer (occlusion) agreement summaries to analysis2.json."""
import json, itertools, os
import numpy as np
from metrics import local_topk_jaccard

R = "/home/claude/xstab/results"
A = json.load(open(f"{R}/analysis2.json")); FAMS = ["lr", "rf", "hgb", "mlp"]
for ds in ["nslkdd", "unsw"]:
    if not all(os.path.exists(f"{R}/occ_{ds}_{f}.npy") for f in FAMS):
        continue
    O = {f: np.load(f"{R}/occ_{ds}_{f}.npy").astype(float) for f in FAMS}; oc = {}
    for f in FAMS:
        oc[f"{f}-{f}"] = float(np.mean([local_topk_jaccard(O[f][i], O[f][j]).mean() for i, j in itertools.combinations(range(8), 2)]))
    for a, b in itertools.combinations(FAMS, 2):
        oc[f"{a}-{b}"] = float(np.mean([local_topk_jaccard(O[a][i], O[b][i]).mean() for i in range(8)]))
    A.setdefault("occ", {})[ds] = oc
    print(ds, {k: round(v, 3) for k, v in oc.items()})
json.dump(A, open(f"{R}/analysis2.json", "w"), indent=1)
